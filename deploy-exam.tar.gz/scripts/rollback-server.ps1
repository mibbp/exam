param(
  [Parameter(Mandatory = $true)] [string]$Host,
  [Parameter(Mandatory = $true)] [string]$User,
  [Parameter(Mandatory = $true)] [string]$Password,
  [string]$ProjectDir = "/mnt/ai-workspace/exam",
  [string]$ReleaseRoot = "/mnt/ai-workspace/exam_releases",
  [string]$ComposeCmd = "docker-compose",
  [string]$Services = "backend frontend",
  [string]$Backup = ""
)

$args = @(
  "$PSScriptRoot/server_release.py",
  "--host", $Host,
  "--user", $User,
  "--password", $Password,
  "--project-dir", $ProjectDir,
  "--release-root", $ReleaseRoot,
  "--compose-cmd", $ComposeCmd,
  "--services", $Services,
  "rollback"
)

if ($Backup -ne "") {
  $args += @("--backup", $Backup)
}

python @args
