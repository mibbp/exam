﻿import { BadRequestException, ForbiddenException, Injectable } from '@nestjs/common';
import { AttemptStatus, ExamStatus, OpenType, type ExamRecordDetail, type Question } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import type { JwtUser } from '../auth/decorators/current-user.decorator';

@Injectable()
export class AttemptsService {
  constructor(private readonly prisma: PrismaService) {}

  private examAccessibleForUser(
    exam: { openType: OpenType; allowedUserIds: unknown; allowedRoleIds: unknown },
    user: JwtUser,
  ) {
    if (exam.openType === 'PUBLIC') return true;
    if (exam.openType === 'USERS') {
      return Array.isArray(exam.allowedUserIds) && exam.allowedUserIds.includes(user.sub);
    }
    if (exam.openType === 'ROLES') {
      return Array.isArray(exam.allowedRoleIds)
        && exam.allowedRoleIds.some((roleId) => (user.roleIds ?? []).includes(Number(roleId)));
    }
    return false;
  }

  private normalizeAnswer(input: string) {
    return input
      .split(',')
      .map((item) => item.trim())
      .filter(Boolean)
      .sort()
      .join(',');
  }

  private async ensureAttemptDetails(attemptId: number) {
    const attempt = await this.prisma.examAttempt.findUnique({
      where: { id: attemptId },
      include: {
        exam: { include: { examQuestions: { orderBy: { orderNo: 'asc' } } } },
        details: true,
      },
    });
    if (!attempt) {
      return null;
    }

    const existingQuestionIds = new Set(attempt.details.map((detail) => detail.questionId));
    const missing = attempt.exam.examQuestions.filter((item) => !existingQuestionIds.has(item.questionId));

    if (missing.length > 0) {
      await this.prisma.examRecordDetail.createMany({
        data: missing.map((item) => ({ attemptId, questionId: item.questionId })),
        skipDuplicates: true,
      });
    }

    return this.prisma.examAttempt.findUnique({
      where: { id: attemptId },
      include: {
        exam: {
          include: { examQuestions: { include: { question: true }, orderBy: { orderNo: 'asc' } } },
        },
        details: {
          include: { question: true },
          orderBy: { questionId: 'asc' },
        },
      },
    });
  }

  async start(examId: number, user: JwtUser) {
    const exam = await this.prisma.exam.findUnique({
      where: { id: examId },
      include: {
        examQuestions: { include: { question: true }, orderBy: { orderNo: 'asc' } },
      },
    });
    if (!exam || (exam.status !== ExamStatus.PUBLISHED && !exam.isPublished)) {
      throw new BadRequestException('Exam not available');
    }
    if (!this.examAccessibleForUser(exam, user)) {
      throw new ForbiddenException('No permission');
    }

    const now = new Date();
    if (exam.startsAt && now < exam.startsAt) {
      throw new ForbiddenException('Exam not started');
    }
    if (exam.endsAt && now > exam.endsAt) {
      throw new ForbiddenException('Exam ended');
    }

    const latest = await this.prisma.examAttempt.findFirst({
      where: { examId, userId: user.sub },
      orderBy: [{ attemptNo: 'desc' }, { id: 'desc' }],
      include: { details: true },
    });
    if (latest?.status === AttemptStatus.IN_PROGRESS) {
      return this.ensureAttemptDetails(latest.id);
    }

    const attemptCount = await this.prisma.examAttempt.count({ where: { examId, userId: user.sub } });
    if (exam.maxAttempts && attemptCount >= exam.maxAttempts) {
      throw new ForbiddenException('No attempt quota left');
    }

    const created = await this.prisma.examAttempt.create({
      data: {
        examId,
        userId: user.sub,
        attemptNo: attemptCount + 1,
        details: { create: exam.examQuestions.map((item) => ({ questionId: item.questionId })) },
      },
      include: { details: true },
    });
    return created;
  }

  async detail(attemptId: number, userId: number, role: 'ADMIN' | 'STUDENT') {
    const attempt = await this.ensureAttemptDetails(attemptId);
    if (!attempt || (role !== 'ADMIN' && attempt.userId !== userId)) {
      throw new ForbiddenException('No permission');
    }

    return {
      ...attempt,
      details: attempt.details.map((detail) => ({
        ...detail,
        question:
          role === 'ADMIN'
            ? detail.question
            : {
                ...detail.question,
                answer: '',
              },
      })),
    };
  }

  async questionNav(attemptId: number, userId: number, role: 'ADMIN' | 'STUDENT') {
    const attempt = await this.detail(attemptId, userId, role);
    return {
      attemptId: attempt.id,
      items: attempt.details.map((detail) => ({
        questionId: detail.questionId,
        answered: Boolean(detail.answer),
        isCorrect: detail.isCorrect,
      })),
    };
  }

  async saveAnswer(attemptId: number, questionId: number, userId: number, answer: string) {
    const attempt = await this.prisma.examAttempt.findUnique({ where: { id: attemptId } });
    if (!attempt || attempt.userId !== userId) {
      throw new ForbiddenException('No permission');
    }
    if (attempt.status !== AttemptStatus.IN_PROGRESS) {
      throw new BadRequestException('Attempt already finished');
    }

    const detail = await this.prisma.examRecordDetail.upsert({
      where: { attemptId_questionId: { attemptId, questionId } },
      update: { answer, savedAt: new Date() },
      create: { attemptId, questionId, answer },
    });
    await this.prisma.examAttempt.update({ where: { id: attemptId }, data: { lastSavedAt: new Date() } });
    return detail;
  }

  async submit(attemptId: number, userId: number, forced = false, forcedReason?: string) {
    const attempt = await this.ensureAttemptDetails(attemptId);
    if (!attempt || attempt.userId !== userId) {
      throw new ForbiddenException('No permission');
    }
    if (attempt.status !== AttemptStatus.IN_PROGRESS) {
      return attempt;
    }

    let total = 0;
    for (const detail of attempt.details) {
      const expected = this.normalizeAnswer(detail.question.answer);
      const actual = this.normalizeAnswer(detail.answer ?? '');
      const isCorrect = expected === actual;
      const questionConfig = attempt.exam.examQuestions.find((item) => item.questionId === detail.questionId);
      const fullScore = questionConfig?.scoreOverride ?? detail.question.score;
      const score = isCorrect ? fullScore : 0;
      total += score;
      await this.prisma.examRecordDetail.update({
        where: { attemptId_questionId: { attemptId, questionId: detail.questionId } },
        data: { isCorrect, score },
      });
    }

    return this.prisma.examAttempt.update({
      where: { id: attemptId },
      data: {
        status: forced ? AttemptStatus.FORCED_SUBMITTED : AttemptStatus.SUBMITTED,
        submittedAt: new Date(),
        score: total,
        durationSeconds: Math.max(0, Math.round((Date.now() - attempt.startedAt.getTime()) / 1000)),
        forcedSubmitReason: forced ? forcedReason ?? 'anti-cheat' : null,
      },
    });
  }

  async result(attemptId: number, userId: number, role: 'ADMIN' | 'STUDENT') {
    return this.detail(attemptId, userId, role);
  }

  async myExams(user: JwtUser) {
    const now = new Date();
    const [publishedExams, attempts] = await Promise.all([
      this.prisma.exam.findMany({
        where: { status: ExamStatus.PUBLISHED },
        include: { examQuestions: true },
        orderBy: { id: 'desc' },
      }),
      this.prisma.examAttempt.findMany({
        where: { userId: user.sub },
        include: {
          exam: true,
          details: { include: { question: true } },
        },
        orderBy: [{ id: 'desc' }],
      }),
    ]);

    const attemptsByExam = new Map<number, typeof attempts>();
    for (const attempt of attempts) {
      const current = attemptsByExam.get(attempt.examId) ?? [];
      current.push(attempt);
      attemptsByExam.set(attempt.examId, current);
    }

    const available = publishedExams
      .filter((exam) => this.examAccessibleForUser(exam, user))
      .map((exam) => {
        const examAttempts = attemptsByExam.get(exam.id) ?? [];
        const latestAttempt = examAttempts[0] ?? null;
        const startReady = !exam.startsAt || now >= exam.startsAt;
        const notEnded = !exam.endsAt || now <= exam.endsAt;
        const remainingAttempts = exam.maxAttempts ? Math.max(exam.maxAttempts - examAttempts.length, 0) : null;
        const hasRunningAttempt = examAttempts.some((item) => item.status === AttemptStatus.IN_PROGRESS);
        const canStart = startReady && notEnded && (!exam.maxAttempts || examAttempts.length < exam.maxAttempts) && !hasRunningAttempt;
        const status = hasRunningAttempt ? 'ONGOING' : startReady ? (notEnded ? 'READY' : 'FINISHED') : 'UPCOMING';
        return {
          examId: exam.id,
          title: exam.title,
          durationMinutes: exam.durationMinutes,
          startsAt: exam.startsAt,
          endsAt: exam.endsAt,
          questionCount: exam.examQuestions.length,
          canStart,
          status,
          attemptId: latestAttempt?.id ?? null,
          score: latestAttempt?.score ?? null,
          totalScore: exam.examQuestions.reduce((sum, item) => sum + (item.scoreOverride ?? 0), 0),
          passScore: exam.passScore,
          remainingAttempts,
          maxAttempts: exam.maxAttempts,
        };
      });

    const history = attempts.map((attempt) => ({
      attemptId: attempt.id,
      examId: attempt.examId,
      title: attempt.exam.title,
      status: attempt.status,
      score: attempt.score,
      startedAt: attempt.startedAt,
      submittedAt: attempt.submittedAt,
      wrongCount: attempt.details.filter((detail) => detail.isCorrect === false).length,
      passScore: attempt.exam.passScore,
      attemptNo: attempt.attemptNo,
    }));

    return { available, history };
  }

  async myWrongQuestions(userId: number, attemptId?: number) {
    const attempts = await this.prisma.examAttempt.findMany({
      where: {
        userId,
        ...(attemptId ? { id: attemptId } : {}),
        status: { in: [AttemptStatus.SUBMITTED, AttemptStatus.FORCED_SUBMITTED] },
      },
      include: {
        exam: true,
        details: { include: { question: true } },
      },
      orderBy: { id: 'desc' },
    });

    const rows: Array<Record<string, unknown>> = [];
    for (const attempt of attempts) {
      for (const detail of attempt.details) {
        if (detail.isCorrect === false) {
          rows.push(this.toWrongQuestionRow(attempt.id, attempt.examId, attempt.exam.title, detail));
        }
      }
    }
    return rows;
  }

  async antiCheatEvent(attemptId: number, userId: number, eventType: string, message?: string) {
    const attempt = await this.prisma.examAttempt.findUnique({ where: { id: attemptId }, include: { exam: true } });
    if (!attempt || attempt.userId !== userId) {
      throw new ForbiddenException('No permission');
    }
    if (attempt.status !== AttemptStatus.IN_PROGRESS) {
      return { forcedSubmit: false, antiCheatViolationCount: attempt.antiCheatViolationCount };
    }

    const updated = await this.prisma.examAttempt.update({
      where: { id: attemptId },
      data: {
        antiCheatViolationCount: { increment: 1 },
        antiCheatEvents: { create: { eventType, message } },
      },
      include: { exam: true },
    });

    if (updated.exam.antiCheatEnabled && updated.antiCheatViolationCount >= updated.exam.antiCheatThreshold) {
      await this.submit(attemptId, userId, true, eventType);
      return { forcedSubmit: true, antiCheatViolationCount: updated.antiCheatViolationCount };
    }
    return { forcedSubmit: false, antiCheatViolationCount: updated.antiCheatViolationCount };
  }

  private toWrongQuestionRow(
    attemptId: number,
    examId: number,
    examTitle: string,
    detail: ExamRecordDetail & { question: Question },
  ) {
    return {
      attemptId,
      examId,
      examTitle,
      questionId: detail.questionId,
      questionType: detail.question.type,
      content: detail.question.content,
      options: detail.question.options,
      analysis: detail.question.analysis,
      myAnswer: detail.answer,
      answer: detail.question.answer,
      score: detail.score ?? 0,
      fullScore: detail.question.score,
    };
  }
}
