import { BadRequestException, Injectable } from '@nestjs/common';
import * as crypto from 'crypto';
import * as XLSX from 'xlsx';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateQuestionDto } from './dto/create-question.dto';
import { UpdateQuestionDto } from './dto/update-question.dto';

@Injectable()
export class QuestionsService {
  constructor(private readonly prisma: PrismaService) {}

  private makeHash(content: string, options: string[]) {
    return crypto.createHash('sha256').update(`${content.trim()}|${options.join('|')}`).digest('hex');
  }

  async create(dto: CreateQuestionDto) {
    const contentHash = this.makeHash(dto.content, dto.options);
    return this.prisma.question.upsert({
      where: { contentHash },
      update: {
        ...dto,
        difficulty: dto.difficulty ?? 1,
        tags: dto.tags ?? [],
        knowledgePoints: dto.knowledgePoints ?? [],
        status: dto.status ?? 'ACTIVE',
      },
      create: {
        ...dto,
        difficulty: dto.difficulty ?? 1,
        tags: dto.tags ?? [],
        knowledgePoints: dto.knowledgePoints ?? [],
        status: dto.status ?? 'ACTIVE',
        contentHash,
      },
      include: { repository: true },
    });
  }

  async findAll(params: {
    repositoryId?: number;
    type?: string;
    difficulty?: number;
    hasAnalysis?: boolean;
    status?: string;
    tag?: string;
    includeAnswer?: boolean;
    keyword?: string;
    page?: number;
    pageSize?: number;
  }) {
    const page = params.page ?? 1;
    const pageSize = Math.min(params.pageSize ?? 20, 100);
    const where = {
      ...(params.repositoryId ? { repositoryId: params.repositoryId } : {}),
      ...(params.type ? { type: params.type as never } : {}),
      ...(params.difficulty ? { difficulty: params.difficulty } : {}),
      ...(params.status ? { status: params.status as never } : {}),
      ...(params.hasAnalysis === undefined
        ? {}
        : params.hasAnalysis
          ? { analysis: { not: null } }
          : { OR: [{ analysis: null }, { analysis: '' }] }),
      ...(params.keyword ? { content: { contains: params.keyword } } : {}),
    };
    const [total, rows] = await Promise.all([
      this.prisma.question.count({ where }),
      this.prisma.question.findMany({
        where,
        orderBy: { id: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: { repository: true },
      }),
    ]);
    const filtered = !params.tag
      ? rows
      : rows.filter((q) => Array.isArray(q.tags) && q.tags.includes(params.tag as never));

    return {
      total,
      page,
      pageSize,
      rows: params.includeAnswer === false ? filtered.map((q) => ({ ...q, answer: '' })) : filtered,
    };
  }

  async update(id: number, dto: UpdateQuestionDto) {
    const original = await this.prisma.question.findUnique({ where: { id } });
    if (!original) {
      throw new BadRequestException('Question not found');
    }
    const mergedOptions = dto.options ?? (original.options as string[]);
    const mergedContent = dto.content ?? original.content;
    const contentHash = this.makeHash(mergedContent, mergedOptions);
    return this.prisma.question.update({
      where: { id },
      data: {
        ...dto,
        contentHash,
      },
      include: { repository: true },
    });
  }

  async remove(id: number) {
    await this.prisma.question.delete({ where: { id } });
    return { ok: true };
  }

  async export(repositoryId?: number) {
    const rows = await this.prisma.question.findMany({
      where: repositoryId ? { repositoryId } : undefined,
      orderBy: { id: 'desc' },
      include: { repository: true },
    });
    return { rows };
  }

  async importFromSheet(buffer: Buffer, repositoryId?: number) {
    const workbook = XLSX.read(buffer, { type: 'buffer' });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json<Record<string, string>>(sheet, { defval: '' });
    const errors: Array<{ row: number; reason: string }> = [];
    let successCount = 0;

    for (let i = 0; i < rows.length; i += 1) {
      const row = rows[i];
      const content = String(row['��Ŀ����'] ?? row['content'] ?? '').trim();
      if (!content) {
        errors.push({ row: i + 2, reason: '��Ŀ����Ϊ��' });
        continue;
      }
      const optionA = String(row['ѡ��A'] ?? row['A'] ?? '').trim();
      const optionB = String(row['ѡ��B'] ?? row['B'] ?? '').trim();
      const optionC = String(row['ѡ��C'] ?? row['C'] ?? '').trim();
      const optionD = String(row['ѡ��D'] ?? row['D'] ?? '').trim();
      const answer = String(row['��ȷ��'] ?? row['answer'] ?? '').replace(/\s+/g, '');
      const score = Number(row['��Ŀ��ֵ'] ?? row['score'] ?? 1);
      const analysis = String(row['��Ŀ����'] ?? row['analysis'] ?? '');
      const difficulty = Number(row['�Ѷ�'] ?? row['difficulty'] ?? 1);
      const tags = String(row['��ǩ'] ?? row['tags'] ?? '')
        .split(',')
        .map((item) => item.trim())
        .filter(Boolean);

      const options = [optionA, optionB, optionC, optionD].filter(Boolean);
      if (options.length < 2 || !answer) {
        errors.push({ row: i + 2, reason: 'ѡ���𰸲��Ϸ�' });
        continue;
      }

      const answerParts = answer.split(',').map((x) => x.trim()).filter(Boolean);
      const type = answerParts.length > 1 ? 'MULTIPLE' : options.length <= 2 ? 'TRUE_FALSE' : 'SINGLE';
      const contentHash = this.makeHash(content, options);

      await this.prisma.question.upsert({
        where: { contentHash },
        update: {
          repositoryId,
          type: type as never,
          content,
          options,
          answer,
          score: Number.isFinite(score) ? score : 1,
          analysis,
          difficulty: Number.isFinite(difficulty) ? difficulty : 1,
          tags,
          knowledgePoints: [],
          status: 'ACTIVE',
        },
        create: {
          repositoryId,
          type: type as never,
          content,
          options,
          answer,
          score: Number.isFinite(score) ? score : 1,
          analysis,
          difficulty: Number.isFinite(difficulty) ? difficulty : 1,
          tags,
          knowledgePoints: [],
          status: 'ACTIVE',
          contentHash,
        },
      });
      successCount += 1;
    }

    return { total: rows.length, successCount, errors };
  }
}
