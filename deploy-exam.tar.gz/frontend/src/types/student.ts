﻿import type { AttemptStatus } from './common';
import type { Question } from './question-bank';

export interface MyExamAvailable {
  examId: number;
  title: string;
  durationMinutes: number;
  startsAt?: string | null;
  endsAt?: string | null;
  questionCount: number;
  canStart: boolean;
  status: 'UPCOMING' | 'READY' | 'ONGOING' | 'FINISHED';
  attemptId?: number | null;
  score?: number | null;
  totalScore: number;
  passScore: number;
  remainingAttempts?: number | null;
  maxAttempts?: number | null;
}

export interface MyExamHistory {
  attemptId: number;
  examId: number;
  title: string;
  status: AttemptStatus;
  score?: number | null;
  startedAt?: string | null;
  submittedAt?: string | null;
  wrongCount: number;
  passScore: number;
  attemptNo: number;
}

export interface WrongQuestion {
  attemptId: number;
  examId: number;
  examTitle: string;
  questionId: number;
  questionType: string;
  content: string;
  options: string[];
  analysis?: string | null;
  myAnswer?: string | null;
  answer: string;
  score: number;
  fullScore: number;
}

export interface AttemptDetail {
  id: number;
  examId: number;
  userId: number;
  attemptNo: number;
  status: AttemptStatus;
  startedAt: string;
  submittedAt?: string | null;
  score?: number | null;
  durationSeconds?: number | null;
  antiCheatViolationCount: number;
  exam: {
    id: number;
    title: string;
    durationMinutes: number;
    passScore: number;
    antiCheatEnabled: boolean;
    antiCheatThreshold: number;
  };
  details: Array<{
    questionId: number;
    answer?: string | null;
    isCorrect?: boolean | null;
    score?: number | null;
    question: Question;
  }>;
}

