﻿import type { AttemptStatus, ExamStatus, OpenType } from './common';
import type { Question } from './question-bank';

export interface ExamQuestionConfig {
  questionId: number;
  orderNo: number;
  scoreOverride?: number | null;
  question?: Question;
}

export interface Exam {
  id: number;
  title: string;
  description?: string | null;
  durationMinutes: number;
  passScore: number;
  maxAttempts?: number | null;
  startsAt?: string | null;
  endsAt?: string | null;
  status: ExamStatus;
  isPublished: boolean;
  openType: OpenType;
  allowedUserIds?: number[];
  allowedRoleIds?: number[];
  allowReview: boolean;
  shuffleQuestions: boolean;
  shuffleOptions: boolean;
  antiCheatEnabled: boolean;
  antiCheatThreshold: number;
  showResultMode: 'IMMEDIATE' | 'AFTER_SUBMIT' | 'MANUAL';
  examQuestions: ExamQuestionConfig[];
  creator?: { id: number; username: string; displayName?: string | null } | null;
  _count?: { attempts: number };
}

export interface ExamScoreboardRow {
  id: number;
  attemptNo: number;
  userId: number;
  username: string;
  displayName?: string | null;
  status: AttemptStatus;
  score?: number | null;
  startedAt?: string | null;
  submittedAt?: string | null;
  antiCheatViolationCount: number;
}

export interface DashboardOverview {
  stats: {
    examCount: number;
    publishedExamCount: number;
    ongoingExamCount: number;
    repositoryCount: number;
    questionCount: number;
    userCount: number;
  };
  shortcuts: Array<{ key: string; title: string; path: string }>;
  recentExams: Exam[];
  recentRepositories: Array<{ id: number; name: string; category?: string | null; _count?: { questions: number } }>;
}

