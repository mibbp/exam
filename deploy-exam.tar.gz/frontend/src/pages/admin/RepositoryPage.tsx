﻿import { App as AntApp, Button, Card, Form, Input, Modal, Select, Table, Tag } from 'antd';
import { useEffect, useState } from 'react';
import { usePermission } from '../../app/AuthContext';
import { createRepository, listRepositories, updateRepository } from '../../services/repositories';
import type { PagedResult, QuestionRepository } from '../../types';

export function RepositoryPage() {
  const { message } = AntApp.useApp();
  const [list, setList] = useState<PagedResult<QuestionRepository>>({ total: 0, page: 1, pageSize: 20, rows: [] });
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<QuestionRepository | null>(null);
  const [form] = Form.useForm();
  const canCreate = usePermission('repositories.create');
  const canUpdate = usePermission('repositories.update');

  async function load(page = 1, pageSize = 20) {
    setLoading(true);
    try {
      setList(await listRepositories({ page, pageSize }));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { void load(); }, []);

  return (
    <Card
      title="题库管理"
      extra={canCreate ? <Button type="primary" onClick={() => { setEditing(null); form.resetFields(); form.setFieldsValue({ status: 'ACTIVE' }); setOpen(true); }}>新建题库</Button> : null}
    >
      <Table
        rowKey="id"
        loading={loading}
        dataSource={list.rows}
        pagination={{ current: list.page, pageSize: list.pageSize, total: list.total, onChange: (p, ps) => void load(p, ps) }}
        columns={[
          { title: '题库名称', dataIndex: 'name' },
          { title: '分类', dataIndex: 'category', render: (value) => value || '未分类' },
          { title: '状态', dataIndex: 'status', render: (value) => <Tag color={value === 'ACTIVE' ? 'green' : 'default'}>{value}</Tag> },
          { title: '题量', render: (_, row) => row._count?.questions ?? 0 },
          { title: '描述', dataIndex: 'description', ellipsis: true },
          { title: '操作', render: (_, row) => canUpdate ? <Button type="link" onClick={() => { setEditing(row); form.setFieldsValue(row); setOpen(true); }}>编辑</Button> : '-' },
        ]}
      />
      <Modal open={open} title={editing ? '编辑题库' : '新建题库'} onCancel={() => setOpen(false)} onOk={() => form.submit()} destroyOnClose>
        <Form
          form={form}
          layout="vertical"
          onFinish={async (values) => {
            try {
              if (editing) await updateRepository(editing.id, values);
              else await createRepository(values);
              message.success('题库已保存');
              setOpen(false);
              await load(list.page, list.pageSize);
            } catch {
              message.error('保存题库失败');
            }
          }}
        >
          <Form.Item label="题库名称" name="name" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item label="分类" name="category"><Input /></Form.Item>
          <Form.Item label="状态" name="status"><Select options={[{ value: 'ACTIVE', label: '启用' }, { value: 'ARCHIVED', label: '归档' }]} /></Form.Item>
          <Form.Item label="描述" name="description"><Input.TextArea rows={4} /></Form.Item>
        </Form>
      </Modal>
    </Card>
  );
}
