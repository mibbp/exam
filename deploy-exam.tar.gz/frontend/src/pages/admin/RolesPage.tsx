﻿import { App as AntApp, Button, Card, Checkbox, Drawer, Form, Input, Modal, Space, Table, Tag } from 'antd';
import { useEffect, useMemo, useState } from 'react';
import { usePermission } from '../../app/AuthContext';
import { createRole, listPermissions, listRoles, updateRole, updateRolePermissions } from '../../services/roles';
import type { Permission, Role } from '../../types';

export function RolesPage() {
  const { message } = AntApp.useApp();
  const [roles, setRoles] = useState<Role[]>([]);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [open, setOpen] = useState(false);
  const [permissionsOpen, setPermissionsOpen] = useState(false);
  const [editing, setEditing] = useState<Role | null>(null);
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [checkedPermissions, setCheckedPermissions] = useState<string[]>([]);
  const [form] = Form.useForm();
  const canCreate = usePermission('roles.create');
  const canUpdate = usePermission('roles.update');
  const canAssign = usePermission('roles.assign');

  async function load() {
    const [roleRows, permissionRows] = await Promise.all([listRoles(), listPermissions()]);
    setRoles(roleRows);
    setPermissions(permissionRows);
  }

  useEffect(() => { void load(); }, []);

  const groupedPermissions = useMemo(() => permissions.reduce<Record<string, Permission[]>>((acc, permission) => {
    acc[permission.category] = acc[permission.category] || [];
    acc[permission.category].push(permission);
    return acc;
  }, {}), [permissions]);

  return (
    <Card title="角色管理" extra={canCreate ? <Button type="primary" onClick={() => { setEditing(null); form.resetFields(); setOpen(true); }}>新建角色</Button> : null}>
      <Table
        rowKey="id"
        dataSource={roles}
        columns={[
          { title: '角色编码', dataIndex: 'code' },
          { title: '角色名称', dataIndex: 'name' },
          { title: '描述', dataIndex: 'description', render: (value) => value || '未填写' },
          { title: '系统角色', dataIndex: 'isSystem', render: (value) => <Tag color={value ? 'gold' : 'default'}>{value ? '系统' : '自定义'}</Tag> },
          { title: '绑定用户', render: (_, row) => row._count?.userAssignments ?? 0 },
          {
            title: '操作',
            render: (_, row) => (
              <Space>
                {canUpdate ? <Button type="link" onClick={() => { setEditing(row); form.setFieldsValue(row); setOpen(true); }}>编辑</Button> : null}
                {canAssign ? <Button type="link" onClick={() => {
                  setSelectedRole(row);
                  setCheckedPermissions((row.permissions || []).map((item) => item.permission.code));
                  setPermissionsOpen(true);
                }}>菜单授权</Button> : null}
              </Space>
            ),
          },
        ]}
      />
      <Modal open={open} title={editing ? '编辑角色' : '新建角色'} onCancel={() => setOpen(false)} onOk={() => form.submit()} destroyOnClose>
        <Form
          form={form}
          layout="vertical"
          onFinish={async (values) => {
            if (editing) await updateRole(editing.id, values);
            else await createRole(values);
            message.success('角色已保存');
            setOpen(false);
            await load();
          }}
        >
          {!editing && <Form.Item name="code" label="角色编码" rules={[{ required: true }]}><Input /></Form.Item>}
          <Form.Item name="name" label="角色名称" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="description" label="描述"><Input.TextArea rows={4} /></Form.Item>
        </Form>
      </Modal>
      <Drawer
        open={permissionsOpen}
        title={`菜单授权 · ${selectedRole?.name || ''}`}
        width={560}
        onClose={() => setPermissionsOpen(false)}
        extra={canAssign ? <Button type="primary" onClick={async () => {
          if (!selectedRole) return;
          await updateRolePermissions(selectedRole.id, checkedPermissions);
          message.success('权限已更新');
          setPermissionsOpen(false);
          await load();
        }}>保存权限</Button> : null}
      >
        <Space direction="vertical" style={{ width: '100%' }}>
          {Object.entries(groupedPermissions).map(([category, items]) => (
            <Card key={category} size="small" title={category}>
              <Checkbox.Group
                value={checkedPermissions}
                onChange={(values) => setCheckedPermissions(values as string[])}
                options={items.map((item) => ({ label: item.name, value: item.code }))}
              />
            </Card>
          ))}
        </Space>
      </Drawer>
    </Card>
  );
}
