﻿import { App as AntApp, Button, Card, Col, Empty, List, Row, Skeleton, Statistic, Typography } from 'antd';
import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../app/AuthContext';
import { getDashboardOverview } from '../../services/dashboard';
import type { DashboardOverview } from '../../types';

const shortcutPermissionMap: Record<string, string> = {
  'new-exam': 'exams.create',
  'import-questions': 'questions.import',
  roles: 'roles.view',
  users: 'users.view',
};

export function AdminDashboardPage() {
  const { message } = AntApp.useApp();
  const auth = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState<DashboardOverview | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    void (async () => {
      try {
        setLoading(true);
        setData(await getDashboardOverview());
      } catch {
        message.error('加载工作台失败');
      } finally {
        setLoading(false);
      }
    })();
  }, [message]);

  const visibleShortcuts = useMemo(() => {
    const permissions = auth.user?.permissions ?? [];
    return (data?.shortcuts ?? []).filter((shortcut) => permissions.includes(shortcutPermissionMap[shortcut.key] ?? '__missing__'));
  }, [auth.user?.permissions, data?.shortcuts]);

  if (loading) {
    return <Skeleton active paragraph={{ rows: 12 }} />;
  }

  if (!data) {
    return <Empty description="暂无工作台数据" />;
  }

  return (
    <div className="stack-gap">
      <Row gutter={[16, 16]}>
        <Col xs={24} sm={12} xl={8}><Card><Statistic title="考试总数" value={data.stats.examCount} /></Card></Col>
        <Col xs={24} sm={12} xl={8}><Card><Statistic title="已发布考试" value={data.stats.publishedExamCount} /></Card></Col>
        <Col xs={24} sm={12} xl={8}><Card><Statistic title="进行中考试" value={data.stats.ongoingExamCount} /></Card></Col>
        <Col xs={24} sm={12} xl={8}><Card><Statistic title="题库数量" value={data.stats.repositoryCount} /></Card></Col>
        <Col xs={24} sm={12} xl={8}><Card><Statistic title="试题总数" value={data.stats.questionCount} /></Card></Col>
        <Col xs={24} sm={12} xl={8}><Card><Statistic title="用户总数" value={data.stats.userCount} /></Card></Col>
      </Row>

      <Card title="快捷入口">
        {visibleShortcuts.length === 0 ? (
          <Empty description="当前账号没有快捷操作权限" />
        ) : (
          <Row gutter={[12, 12]}>
            {visibleShortcuts.map((shortcut) => (
              <Col key={shortcut.key} xs={24} md={12} xl={6}>
                <Button block size="large" className="quick-action" onClick={() => navigate(shortcut.path)}>
                  {shortcut.title}
                </Button>
              </Col>
            ))}
          </Row>
        )}
      </Card>

      <Row gutter={[16, 16]}>
        <Col xs={24} xl={14}>
          <Card title="最近考试">
            <List
              dataSource={data.recentExams}
              renderItem={(exam) => (
                <List.Item>
                  <List.Item.Meta
                    title={exam.title}
                    description={`状态：${exam.status} · 时长 ${exam.durationMinutes} 分钟 · 及格分 ${exam.passScore}`}
                  />
                  <Typography.Text type="secondary">{exam._count?.attempts ?? 0} 人次</Typography.Text>
                </List.Item>
              )}
            />
          </Card>
        </Col>
        <Col xs={24} xl={10}>
          <Card title="最新题库">
            <List
              dataSource={data.recentRepositories}
              renderItem={(repository) => (
                <List.Item>
                  <List.Item.Meta
                    title={repository.name}
                    description={`分类：${repository.category || '未分类'} · 试题 ${repository._count?.questions ?? 0} 道`}
                  />
                </List.Item>
              )}
            />
          </Card>
        </Col>
      </Row>
    </div>
  );
}
