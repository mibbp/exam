﻿import { App as AntApp, Button, Card, Col, Empty, Row, Segmented, Space, Tabs, Tag, Typography } from 'antd';
import dayjs from 'dayjs';
import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { listMyExams } from '../../services/attempts';
import type { MyExamAvailable, MyExamHistory } from '../../types';

export function StudentExamHallPage() {
  const { message } = AntApp.useApp();
  const navigate = useNavigate();
  const [available, setAvailable] = useState<MyExamAvailable[]>([]);
  const [history, setHistory] = useState<MyExamHistory[]>([]);
  const [status, setStatus] = useState<'ALL' | 'UPCOMING' | 'READY' | 'ONGOING' | 'FINISHED'>('ALL');
  const [loading, setLoading] = useState(false);

  async function load() {
    try {
      setLoading(true);
      const data = await listMyExams();
      setAvailable(data.available);
      setHistory(data.history);
    } catch {
      message.error('加载考试列表失败');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { void load(); }, []);

  const filtered = useMemo(
    () => available.filter((item) => status === 'ALL' || item.status === status),
    [available, status],
  );

  return (
    <div className="stack-gap">
      <Card>
        <Space direction="vertical" size={16} style={{ width: '100%' }}>
          <div>
            <Typography.Text className="eyebrow">Exam Hall</Typography.Text>
            <Typography.Title level={2}>考试大厅</Typography.Title>
            <Typography.Paragraph type="secondary">查看可参加考试、考试次数和历史成绩，完成完整答题闭环。</Typography.Paragraph>
          </div>
          <Segmented
            value={status}
            onChange={(value) => setStatus(value as typeof status)}
            options={[
              { label: '全部', value: 'ALL' },
              { label: '未开始', value: 'UPCOMING' },
              { label: '可参加', value: 'READY' },
              { label: '进行中', value: 'ONGOING' },
              { label: '已结束', value: 'FINISHED' },
            ]}
          />
        </Space>
      </Card>

      <Tabs
        items={[
          {
            key: 'hall',
            label: '考试大厅',
            children: filtered.length === 0 ? (
              <Card><Empty description="当前筛选条件下没有考试" /></Card>
            ) : (
              <Row gutter={[16, 16]}>
                {filtered.map((item) => (
                  <Col key={item.examId} xs={24} xl={12}>
                    <Card loading={loading} className="exam-card">
                      <Space direction="vertical" size={12} style={{ width: '100%' }}>
                        <div>
                          <Typography.Title level={4}>{item.title}</Typography.Title>
                          <Space wrap>
                            <Tag color={item.status === 'READY' ? 'green' : item.status === 'ONGOING' ? 'blue' : 'default'}>{item.status}</Tag>
                            <Tag>时长 {item.durationMinutes} 分钟</Tag>
                            <Tag>总分 {item.totalScore}</Tag>
                            <Tag>及格分 {item.passScore}</Tag>
                          </Space>
                        </div>
                        <Typography.Text type="secondary">
                          {item.startsAt ? dayjs(item.startsAt).format('YYYY-MM-DD HH:mm') : '随时开始'} - {item.endsAt ? dayjs(item.endsAt).format('YYYY-MM-DD HH:mm') : '不限结束'}
                        </Typography.Text>
                        <Typography.Text type="secondary">
                          剩余次数：{item.remainingAttempts === null ? '不限' : item.remainingAttempts} / {item.maxAttempts ?? '不限'}
                        </Typography.Text>
                        <Space>
                          <Button onClick={() => navigate(`/student/exams/${item.examId}/check`)}>查看详情</Button>
                          {item.attemptId && item.status === 'ONGOING' && (
                            <Button type="primary" onClick={() => navigate(`/student/attempts/${item.attemptId}`)}>继续答题</Button>
                          )}
                        </Space>
                      </Space>
                    </Card>
                  </Col>
                ))}
              </Row>
            ),
          },
          {
            key: 'history',
            label: '我的考试',
            children: (
              <Row gutter={[16, 16]}>
                {history.map((item) => (
                  <Col key={item.attemptId} xs={24} xl={12}>
                    <Card>
                      <Space direction="vertical" size={8} style={{ width: '100%' }}>
                        <Typography.Title level={5}>{item.title}</Typography.Title>
                        <Space wrap>
                          <Tag color={item.status === 'SUBMITTED' ? 'green' : item.status === 'FORCED_SUBMITTED' ? 'orange' : 'blue'}>{item.status}</Tag>
                          <Tag>第 {item.attemptNo} 次</Tag>
                          <Tag>得分 {item.score ?? 0}</Tag>
                          <Tag>错题 {item.wrongCount}</Tag>
                        </Space>
                        <Typography.Text type="secondary">提交时间：{item.submittedAt ? dayjs(item.submittedAt).format('YYYY-MM-DD HH:mm:ss') : '未提交'}</Typography.Text>
                        <Space>
                          <Button onClick={() => navigate(`/student/wrong-questions/${item.attemptId}`)}>错题回顾</Button>
                          <Button onClick={() => navigate(`/student/exams/${item.examId}/check`)}>再次查看</Button>
                        </Space>
                      </Space>
                    </Card>
                  </Col>
                ))}
              </Row>
            ),
          },
        ]}
      />
    </div>
  );
}

