﻿import { Alert, App as AntApp, Button, Card, Col, Layout, List, Modal, Radio, Row, Space, Statistic, Tag, Typography } from 'antd';
import dayjs from 'dayjs';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getAttempt, reportAntiCheat, saveAnswer, submitAttempt } from '../../services/attempts';
import type { AttemptDetail } from '../../types';

const { Sider, Content } = Layout;

export function StudentExamSessionPage() {
  const { message } = AntApp.useApp();
  const navigate = useNavigate();
  const params = useParams();
  const [attempt, setAttempt] = useState<AttemptDetail | null>(null);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [currentIndex, setCurrentIndex] = useState(0);
  const [remaining, setRemaining] = useState(0);
  const pendingSaveRef = useRef<number | null>(null);

  async function load() {
    if (!params.attemptId) return;
    const data = await getAttempt(Number(params.attemptId));
    setAttempt(data);
    setAnswers(Object.fromEntries(data.details.map((detail) => [detail.questionId, detail.answer || ''])));
    setRemaining(data.exam.durationMinutes * 60 - Math.max(data.durationSeconds || 0, 0));
  }

  useEffect(() => { void load(); }, [params.attemptId]);

  useEffect(() => {
    if (!attempt) return;
    const timer = window.setInterval(() => {
      setRemaining((value) => {
        if (value <= 1) {
          window.clearInterval(timer);
          void (async () => {
            await submitAttempt(attempt.id);
            Modal.success({ title: '考试已自动交卷', content: '考试时间已结束，系统已为你自动交卷。' });
            navigate('/student/exams');
          })();
          return 0;
        }
        return value - 1;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [attempt, navigate]);

  useEffect(() => {
    if (!attempt) return;
    if (pendingSaveRef.current) {
      window.clearTimeout(pendingSaveRef.current);
    }
    pendingSaveRef.current = window.setTimeout(() => {
      void Promise.all(
        attempt.details.map((detail) => saveAnswer(attempt.id, detail.questionId, answers[detail.questionId] || '')),
      ).then(() => message.success('答案已自动保存', 0.8)).catch(() => message.error('自动保存失败'));
    }, 700);
    return () => {
      if (pendingSaveRef.current) window.clearTimeout(pendingSaveRef.current);
    };
  }, [answers, attempt, message]);

  useEffect(() => {
    if (!attempt?.exam.antiCheatEnabled) return;
    const handler = async () => {
      if (document.visibilityState !== 'hidden' || !attempt) return;
      const result = await reportAntiCheat(attempt.id, 'visibility-hidden', '考生切换到其他窗口或标签页');
      if (result.forcedSubmit) {
        Modal.warning({ title: '已强制交卷', content: '检测到多次切屏，系统已强制交卷。' });
        navigate('/student/exams');
      }
    };
    document.addEventListener('visibilitychange', handler);
    return () => document.removeEventListener('visibilitychange', handler);
  }, [attempt, navigate]);

  const currentQuestion = useMemo(() => attempt?.details[currentIndex], [attempt, currentIndex]);

  if (!attempt || !currentQuestion) return <Card loading />;

  const minutes = String(Math.floor(remaining / 60)).padStart(2, '0');
  const seconds = String(remaining % 60).padStart(2, '0');

  return (
    <Layout className="exam-session-shell">
      <Sider width={260} className="exam-nav">
        <Typography.Title level={4}>{attempt.exam.title}</Typography.Title>
        <Statistic title="剩余时间" value={`${minutes}:${seconds}`} />
        <Alert type="warning" showIcon message={`切屏超过 ${attempt.exam.antiCheatThreshold} 次将强制交卷`} />
        <List
          size="small"
          dataSource={attempt.details}
          renderItem={(detail, index) => (
            <List.Item onClick={() => setCurrentIndex(index)} className={index === currentIndex ? 'nav-item-active' : 'nav-item'}>
              <Space>
                <Tag color={answers[detail.questionId] ? 'green' : 'default'}>{index + 1}</Tag>
                <Typography.Text ellipsis style={{ width: 180 }}>{detail.question.content}</Typography.Text>
              </Space>
            </List.Item>
          )}
        />
      </Sider>
      <Content className="exam-content">
        <Card>
          <Space direction="vertical" size={20} style={{ width: '100%' }}>
            <Row justify="space-between" align="middle">
              <Col>
                <Typography.Text className="eyebrow">Question {currentIndex + 1}</Typography.Text>
                <Typography.Title level={3}>{currentQuestion.question.content}</Typography.Title>
              </Col>
              <Col>
                <Space>
                  <Tag color="blue">{currentQuestion.question.type}</Tag>
                  <Tag>分值 {currentQuestion.question.score}</Tag>
                </Space>
              </Col>
            </Row>
            <Radio.Group
              value={currentQuestion.question.type === 'MULTIPLE' ? (answers[currentQuestion.questionId] || '').split(',').filter(Boolean) : answers[currentQuestion.questionId] || ''}
              onChange={(event) => {
                const value = Array.isArray(event.target.value) ? event.target.value.join(',') : event.target.value;
                setAnswers((prev) => ({ ...prev, [currentQuestion.questionId]: String(value) }));
              }}
            >
              <Space direction="vertical">
                {currentQuestion.question.options.map((option, index) => {
                  const value = String.fromCharCode(65 + index);
                  return currentQuestion.question.type === 'MULTIPLE' ? (
                    <label key={value} className="option-row">
                      <input
                        type="checkbox"
                        checked={(answers[currentQuestion.questionId] || '').split(',').includes(value)}
                        onChange={(event) => {
                          const current = (answers[currentQuestion.questionId] || '').split(',').filter(Boolean);
                          const next = event.target.checked ? [...current, value] : current.filter((item) => item !== value);
                          setAnswers((prev) => ({ ...prev, [currentQuestion.questionId]: next.join(',') }));
                        }}
                      />
                      <span>{value}. {option}</span>
                    </label>
                  ) : (
                    <Radio key={value} value={value} className="option-row">{value}. {option}</Radio>
                  );
                })}
              </Space>
            </Radio.Group>
            <Space>
              <Button disabled={currentIndex === 0} onClick={() => setCurrentIndex((index) => index - 1)}>上一题</Button>
              <Button disabled={currentIndex === attempt.details.length - 1} onClick={() => setCurrentIndex((index) => index + 1)}>下一题</Button>
              <Button type="primary" danger onClick={async () => {
                await submitAttempt(attempt.id);
                Modal.success({ title: '交卷成功', content: `交卷时间：${dayjs().format('YYYY-MM-DD HH:mm:ss')}` });
                navigate('/student/exams');
              }}>提交试卷</Button>
            </Space>
          </Space>
        </Card>
      </Content>
    </Layout>
  );
}

