﻿import { App as AntApp, Button, Card, Checkbox, Descriptions, Result, Space, Typography } from 'antd';
import dayjs from 'dayjs';
import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getExam } from '../../services/exams';
import { startAttempt } from '../../services/attempts';
import type { Exam } from '../../types';

export function StudentExamCheckPage() {
  const { message } = AntApp.useApp();
  const navigate = useNavigate();
  const params = useParams();
  const [exam, setExam] = useState<Exam | null>(null);
  const [ready, setReady] = useState(false);
  const [loading, setLoading] = useState(true);
  const [starting, setStarting] = useState(false);

  useEffect(() => {
    void (async () => {
      try {
        if (!params.examId) return;
        setLoading(true);
        setExam(await getExam(Number(params.examId)));
      } catch {
        message.error('加载考试信息失败');
      } finally {
        setLoading(false);
      }
    })();
  }, [message, params.examId]);

  if (!params.examId) return <Result status="404" title="考试不存在" />;

  return (
    <Card loading={loading}>
      {exam && (
        <Space direction="vertical" size={24} style={{ width: '100%' }}>
          <div>
            <Typography.Text className="eyebrow">Exam Check</Typography.Text>
            <Typography.Title level={2}>{exam.title}</Typography.Title>
          </div>
          <Descriptions bordered column={1}>
            <Descriptions.Item label="考试时长">{exam.durationMinutes} 分钟</Descriptions.Item>
            <Descriptions.Item label="总题量">{exam.examQuestions.length} 道</Descriptions.Item>
            <Descriptions.Item label="及格分">{exam.passScore} 分</Descriptions.Item>
            <Descriptions.Item label="考试时间">{exam.startsAt ? dayjs(exam.startsAt).format('YYYY-MM-DD HH:mm') : '不限'} - {exam.endsAt ? dayjs(exam.endsAt).format('YYYY-MM-DD HH:mm') : '不限'}</Descriptions.Item>
            <Descriptions.Item label="防作弊">{exam.antiCheatEnabled ? `开启，阈值 ${exam.antiCheatThreshold}` : '关闭'}</Descriptions.Item>
          </Descriptions>
          <Card className="rule-card">
            <Typography.Paragraph>开始考试前请确认网络稳定。考试过程会自动保存作答内容，并在切屏异常时记录防作弊事件。</Typography.Paragraph>
            <Checkbox checked={ready} onChange={(event) => setReady(event.target.checked)}>我已完成设备检查并理解考试规则</Checkbox>
          </Card>
          <Space>
            <Button onClick={() => navigate('/student/exams')}>返回大厅</Button>
            <Button
              type="primary"
              disabled={!ready}
              loading={starting}
              onClick={async () => {
                try {
                  setStarting(true);
                  const attempt = await startAttempt(Number(params.examId));
                  navigate(`/student/attempts/${attempt.id}`);
                } catch {
                  message.error('当前考试不可开始');
                } finally {
                  setStarting(false);
                }
              }}
            >
              开始考试
            </Button>
          </Space>
        </Space>
      )}
    </Card>
  );
}

