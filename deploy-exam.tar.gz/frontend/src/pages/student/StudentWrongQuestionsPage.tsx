﻿import { Card, List, Space, Tag, Typography } from 'antd';
import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { listMyWrongQuestions } from '../../services/attempts';
import type { WrongQuestion } from '../../types';

export function StudentWrongQuestionsPage() {
  const navigate = useNavigate();
  const params = useParams();
  const [rows, setRows] = useState<WrongQuestion[]>([]);

  useEffect(() => {
    void (async () => {
      if (!params.attemptId) return;
      setRows(await listMyWrongQuestions(Number(params.attemptId)));
    })();
  }, [params.attemptId]);

  return (
    <Card title="错题回顾" extra={<Typography.Link onClick={() => navigate('/student/exams')}>返回考试大厅</Typography.Link>}>
      <List
        dataSource={rows}
        renderItem={(row) => (
          <List.Item>
            <Space direction="vertical" style={{ width: '100%' }}>
              <Typography.Title level={5}>{row.content}</Typography.Title>
              <Space wrap>
                {row.options.map((option, index) => <Tag key={option}>{String.fromCharCode(65 + index)}. {option}</Tag>)}
              </Space>
              <Typography.Text>你的答案：{row.myAnswer || '未作答'}</Typography.Text>
              <Typography.Text>正确答案：{row.answer}</Typography.Text>
              <Typography.Paragraph type="secondary">解析：{row.analysis || '暂无解析'}</Typography.Paragraph>
            </Space>
          </List.Item>
        )}
      />
    </Card>
  );
}

