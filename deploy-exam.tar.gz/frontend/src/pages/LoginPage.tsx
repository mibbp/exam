﻿import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { login } from '../services/auth';
import { useAuth } from '../app/AuthContext';

export function LoginPage() {
  const auth = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('Admin@123');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  return (
    <div className="login-shell">
      <div className="login-brand">
        <p className="eyebrow">Exam Workspace</p>
        <h1>在线考试系统</h1>
        <p>对标成熟考试平台的信息架构，构建题库、权限、考试管理和学生考试闭环。</p>
      </div>
      <section className="login-card native-login-card">
        <h2>账号登录</h2>
        <p className="login-hint">演示账号：admin / student</p>
        <form
          className="login-form"
          onSubmit={async (event) => {
            event.preventDefault();
            setError('');
            try {
              setLoading(true);
              const data = await login(username, password);
              auth.setSession({ accessToken: data.accessToken, user: data.user });
              const fallback = data.user.role === 'ADMIN' ? '/admin/dashboard' : '/student/exams';
              const next = (location.state as { from?: { pathname?: string } } | null)?.from?.pathname ?? fallback;
              navigate(next, { replace: true });
            } catch {
              setError('用户名或密码错误');
            } finally {
              setLoading(false);
            }
          }}
        >
          <label>
            <span>用户名</span>
            <input value={username} onChange={(event) => setUsername(event.target.value)} placeholder="请输入用户名" autoComplete="username" />
          </label>
          <label>
            <span>密码</span>
            <input value={password} onChange={(event) => setPassword(event.target.value)} placeholder="请输入密码" type="password" autoComplete="current-password" />
          </label>
          {error ? <div className="login-error">{error}</div> : null}
          <button className="login-submit" type="submit" disabled={loading}>
            {loading ? '登录中...' : '登录并进入工作台'}
          </button>
        </form>
      </section>
    </div>
  );
}
