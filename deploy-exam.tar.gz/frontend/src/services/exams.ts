﻿import api from './client';
import type { Exam, ExamScoreboardRow, PagedResult } from '../types';

export async function listExams(params?: Record<string, unknown>) {
  const { data } = await api.get<PagedResult<Exam>>('/exams', { params });
  return data;
}

export async function getExam(id: number) {
  const { data } = await api.get<Exam>(`/exams/${id}`);
  return data;
}

export async function createExam(payload: Record<string, unknown>) {
  const { data } = await api.post<Exam>('/exams', payload);
  return data;
}

export async function updateExam(id: number, payload: Record<string, unknown>) {
  const { data } = await api.patch<Exam>(`/exams/${id}`, payload);
  return data;
}

export async function publishExam(id: number) {
  await api.post(`/exams/${id}/publish`);
}

export async function unpublishExam(id: number) {
  await api.post(`/exams/${id}/unpublish`);
}

export async function closeExam(id: number) {
  await api.post(`/exams/${id}/close`);
}

export async function deleteExam(id: number) {
  await api.delete(`/exams/${id}`);
}

export async function examScoreboard(examId: number, params?: Record<string, unknown>) {
  const { data } = await api.get<PagedResult<ExamScoreboardRow>>(`/exams/${examId}/scoreboard`, { params });
  return data;
}

export async function exportExamResults(examId: number) {
  const { data } = await api.get(`/exams/${examId}/results/export`);
  return data as { rows: ExamScoreboardRow[] };
}

