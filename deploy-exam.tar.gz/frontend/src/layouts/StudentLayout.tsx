﻿import { Button, Layout, Menu, Space, Tag, Typography } from 'antd';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../app/AuthContext';

const { Header, Content } = Layout;

const items = [{ key: '/student/exams', label: '在线考试' }];

export function StudentLayout() {
  const auth = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <Layout className="student-shell">
      <Header className="student-header">
        <div className="student-brand">
          <Typography.Text className="eyebrow">Student Portal</Typography.Text>
          <Typography.Title level={4}>在线考试中心</Typography.Title>
        </div>
        <Menu
          mode="horizontal"
          theme="dark"
          selectedKeys={[items.find((item) => location.pathname.startsWith(item.key))?.key ?? '/student/exams']}
          items={items}
          onClick={({ key }) => navigate(key)}
          style={{ flex: 1, minWidth: 240, justifyContent: 'center' }}
        />
        <Space>
          <Tag color="cyan">{auth.user?.displayName ?? auth.user?.username}</Tag>
          <Button type="primary" ghost onClick={() => void auth.clearSession()}>退出</Button>
        </Space>
      </Header>
      <Content className="student-content">
        <Outlet />
      </Content>
    </Layout>
  );
}
