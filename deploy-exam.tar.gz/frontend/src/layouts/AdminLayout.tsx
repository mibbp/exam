﻿import { Breadcrumb, Button, Layout, Menu, Space, Tag, Typography } from 'antd';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../app/AuthContext';

const { Header, Sider, Content } = Layout;

const items = [
  { key: '/admin/dashboard', label: '管理首页', permission: 'dashboard.view' },
  { key: '/admin/repositories', label: '题库管理', permission: 'repositories.view' },
  { key: '/admin/questions', label: '试题管理', permission: 'questions.view' },
  { key: '/admin/exams', label: '考试管理', permission: 'exams.view' },
  { key: '/admin/access/roles', label: '角色管理', permission: 'roles.view' },
  { key: '/admin/access/users', label: '用户管理', permission: 'users.view' },
];

export function AdminLayout() {
  const auth = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const visibleItems = items.filter((item) => auth.user?.permissions.includes(item.permission));
  const current = visibleItems.find((item) => location.pathname.startsWith(item.key)) ?? visibleItems[0] ?? items[0];

  return (
    <Layout className="admin-shell">
      <Sider width={240} className="admin-sider">
        <div className="brand-block">
          <Typography.Text className="brand-kicker">ADMIN</Typography.Text>
          <Typography.Title level={4}>考试管理工作台</Typography.Title>
        </div>
        <Menu theme="dark" mode="inline" selectedKeys={[current.key]} items={visibleItems} onClick={({ key }) => navigate(key)} />
      </Sider>
      <Layout>
        <Header className="admin-header">
          <div>
            <Typography.Text type="secondary">当前角色</Typography.Text>
            <div>
              <Typography.Title level={4} style={{ margin: 0 }}>{current.label}</Typography.Title>
            </div>
          </div>
          <Space>
            <Tag color="blue">{auth.user?.displayName ?? auth.user?.username}</Tag>
            <Button type="primary" ghost onClick={() => void auth.clearSession()}>
              退出登录
            </Button>
          </Space>
        </Header>
        <Content className="admin-content">
          <Breadcrumb items={[{ title: '管理后台' }, { title: current.label }]} />
          <div className="page-panel">
            <Outlet />
          </div>
        </Content>
      </Layout>
    </Layout>
  );
}
