﻿import { Navigate, Outlet } from 'react-router-dom';
import { Result } from 'antd';
import { useAuth } from './AuthContext';

const fallbackRoutes: Record<string, string> = {
  'dashboard.view': '/admin/dashboard',
  'repositories.view': '/admin/repositories',
  'questions.view': '/admin/questions',
  'exams.view': '/admin/exams',
  'roles.view': '/admin/access/roles',
  'users.view': '/admin/access/users',
};

function getFallbackPath(permissions: string[]) {
  const candidate = Object.entries(fallbackRoutes).find(([permission]) => permissions.includes(permission));
  return candidate?.[1] ?? '/login';
}

export function RequirePermission({ permission }: { permission: string }) {
  const auth = useAuth();

  if (!auth.user) {
    return <Navigate to="/login" replace />;
  }

  if (!auth.user.permissions.includes(permission)) {
    const fallback = getFallbackPath(auth.user.permissions);
    if (fallback === '/login') {
      return <Result status="403" title="无权限访问该页面" subTitle="当前账号没有对应页面权限。" />;
    }
    return <Navigate to={fallback} replace />;
  }

  return <Outlet />;
}
