﻿import { createContext, useContext, useMemo, useState } from 'react';
import type { PropsWithChildren } from 'react';
import { clearAuthState, getAuthState, setAuthState } from '../services/auth-store';
import { logout as logoutRequest } from '../services/auth';
import type { AuthUser } from '../types';

interface AuthContextValue {
  accessToken: string | null;
  user: AuthUser | null;
  setSession: (session: { accessToken: string | null; user: AuthUser | null }) => void;
  clearSession: () => Promise<void>;
  hasPermission: (permission: string) => boolean;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: PropsWithChildren) {
  const [session, setSessionState] = useState(getAuthState());

  const value = useMemo<AuthContextValue>(
    () => ({
      accessToken: session.accessToken,
      user: session.user,
      setSession(next) {
        setAuthState(next);
        setSessionState(next);
      },
      hasPermission(permission) {
        return Boolean(session.user?.permissions.includes(permission));
      },
      async clearSession() {
        try {
          await logoutRequest();
        } catch {
          // Ignore logout transport errors and clear local session anyway.
        }
        clearAuthState();
        setSessionState({ accessToken: null, user: null });
      },
    }),
    [session],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const value = useContext(AuthContext);
  if (!value) throw new Error('useAuth must be used within AuthProvider');
  return value;
}

export function usePermission(permission: string) {
  return useAuth().hasPermission(permission);
}
