# 在线考试系统

技术栈：
- 前端：React + Vite + Tailwind + Ant Design
- 后端：NestJS + Prisma + MySQL
- 部署：Docker Compose

快速启动：
```bash
cp .env.example infra/.env
cd infra
docker compose --env-file .env up -d --build
```

默认访问：
- 前端：`http://localhost`
- 后端：`http://localhost:3000/api`
