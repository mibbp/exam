import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  const adminPwd = await bcrypt.hash(process.env.SEED_ADMIN_PASSWORD ?? 'Admin@123', 10);
  const studentPwd = await bcrypt.hash(process.env.SEED_STUDENT_PASSWORD ?? 'Student@123', 10);

  await prisma.user.upsert({
    where: { username: 'admin' },
    update: { passwordHash: adminPwd, role: 'ADMIN', status: 'ACTIVE', displayName: '系统管理员' },
    create: { username: 'admin', passwordHash: adminPwd, role: 'ADMIN', status: 'ACTIVE', displayName: '系统管理员' },
  });

  await prisma.user.upsert({
    where: { username: 'student1' },
    update: { passwordHash: studentPwd, role: 'STUDENT', status: 'ACTIVE', displayName: '学生1' },
    create: { username: 'student1', passwordHash: studentPwd, role: 'STUDENT', status: 'ACTIVE', displayName: '学生1' },
  });

  await prisma.user.upsert({
    where: { username: 'student' },
    update: { passwordHash: studentPwd, role: 'STUDENT', status: 'ACTIVE', displayName: '学生' },
    create: { username: 'student', passwordHash: studentPwd, role: 'STUDENT', status: 'ACTIVE', displayName: '学生' },
  });
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (err) => {
    console.error(err);
    await prisma.$disconnect();
    process.exit(1);
  });
