import { BadRequestException, Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateQuestionDto } from './dto/create-question.dto';
import { UpdateQuestionDto } from './dto/update-question.dto';
import * as crypto from 'crypto';
import * as XLSX from 'xlsx';

@Injectable()
export class QuestionsService {
  constructor(private readonly prisma: PrismaService) {}

  private makeHash(content: string, options: string[]) {
    return crypto
      .createHash('sha256')
      .update(`${content.trim()}|${options.join('|')}`)
      .digest('hex');
  }

  async create(dto: CreateQuestionDto) {
    const contentHash = this.makeHash(dto.content, dto.options);
    return this.prisma.question.upsert({
      where: { contentHash },
      update: {
        ...dto,
        difficulty: dto.difficulty ?? 1,
        tags: dto.tags ?? [],
      },
      create: {
        ...dto,
        difficulty: dto.difficulty ?? 1,
        tags: dto.tags ?? [],
        contentHash,
      },
    });
  }

  async findAll(
    type?: string,
    difficulty?: number,
    tag?: string,
    includeAnswer = true,
    keyword?: string,
    page = 1,
    pageSize = 20,
  ) {
    const where = {
      ...(type ? { type: type as never } : {}),
      ...(difficulty ? { difficulty } : {}),
      ...(keyword ? { content: { contains: keyword } } : {}),
    };
    const [total, rows] = await Promise.all([
      this.prisma.question.count({ where }),
      this.prisma.question.findMany({
        where,
        orderBy: { id: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
    ]);
    const filtered = !tag
      ? rows
      : rows.filter((q: { tags: unknown }) => Array.isArray(q.tags) && q.tags.includes(tag));

    const resultRows = includeAnswer
      ? filtered
      : filtered.map((q) => ({
          ...q,
          answer: '',
        }));
    return {
      total,
      page,
      pageSize,
      rows: resultRows,
    };
  }

  async update(id: number, dto: UpdateQuestionDto) {
    const original = await this.prisma.question.findUnique({ where: { id } });
    if (!original) {
      throw new BadRequestException('Question not found');
    }
    const mergedOptions = dto.options ?? (original.options as string[]);
    const mergedContent = dto.content ?? original.content;
    const contentHash = this.makeHash(mergedContent, mergedOptions);
    return this.prisma.question.update({
      where: { id },
      data: {
        ...dto,
        contentHash,
      },
    });
  }

  async remove(id: number) {
    await this.prisma.question.delete({ where: { id } });
    return { ok: true };
  }

  async importFromSheet(buffer: Buffer) {
    const workbook = XLSX.read(buffer, { type: 'buffer' });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json<Record<string, string>>(sheet, {
      defval: '',
    });
    const errors: Array<{ row: number; reason: string }> = [];
    let successCount = 0;

    for (let i = 0; i < rows.length; i += 1) {
      const row = rows[i];
      const content = String(row['题目内容'] ?? '').trim();
      if (!content) {
        errors.push({ row: i + 2, reason: '题目内容为空' });
        continue;
      }
      const optionA = String(row['选项A'] ?? '').trim();
      const optionB = String(row['选项B'] ?? '').trim();
      const optionC = String(row['选项C'] ?? '').trim();
      const optionD = String(row['选项D'] ?? '').trim();
      const answer = String(row['正确答案'] ?? '').replace(/\s+/g, '');
      const score = Number(row['题目分值'] ?? 1);
      const analysis = String(row['题目解析'] ?? '');

      const options = [optionA, optionB, optionC, optionD].filter(Boolean);
      if (options.length < 2 || !answer) {
        errors.push({ row: i + 2, reason: '选项或答案不合法' });
        continue;
      }

      const answerParts = answer.split(',').map((x) => x.trim());
      const type =
        answerParts.length > 1
          ? 'MULTIPLE'
          : options.length <= 2
            ? 'TRUE_FALSE'
            : 'SINGLE';
      const contentHash = this.makeHash(content, options);

      await this.prisma.question.upsert({
        where: { contentHash },
        update: {
          type: type as never,
          content,
          options,
          answer,
          score: Number.isFinite(score) ? score : 1,
          analysis,
        },
        create: {
          type: type as never,
          content,
          options,
          answer,
          score: Number.isFinite(score) ? score : 1,
          analysis,
          difficulty: 1,
          tags: [],
          contentHash,
        },
      });
      successCount += 1;
    }

    return { total: rows.length, successCount, errors };
  }
}
