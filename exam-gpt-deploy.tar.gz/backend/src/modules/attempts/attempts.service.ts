import { BadRequestException, ForbiddenException, Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { ExamStatus } from '@prisma/client';

@Injectable()
export class AttemptsService {
  constructor(private readonly prisma: PrismaService) {}

  private examAccessibleForUser(allowedUserIds: unknown, userId: number) {
    if (!Array.isArray(allowedUserIds) || allowedUserIds.length === 0) {
      return true;
    }
    return allowedUserIds.includes(userId);
  }

  async start(examId: number, userId: number) {
    const exam = await this.prisma.exam.findUnique({
      where: { id: examId },
      include: {
        examQuestions: { include: { question: true }, orderBy: { orderNo: 'asc' } },
      },
    });
    if (!exam || (exam.status !== ExamStatus.PUBLISHED && !exam.isPublished)) {
      throw new BadRequestException('Exam not available');
    }
    if (!this.examAccessibleForUser(exam.allowedUserIds, userId)) {
      throw new ForbiddenException('No permission');
    }

    const now = new Date();
    if (exam.startsAt && now < exam.startsAt) {
      throw new ForbiddenException('Exam not started');
    }
    if (exam.endsAt && now > exam.endsAt) {
      throw new ForbiddenException('Exam ended');
    }

    const existing = await this.prisma.examAttempt.findUnique({
      where: { examId_userId: { examId, userId } },
      include: { details: true },
    });
    if (existing) {
      return existing;
    }

    return this.prisma.examAttempt.create({
      data: {
        examId,
        userId,
      },
      include: { details: true },
    });
  }

  async saveAnswer(attemptId: number, questionId: number, userId: number, answer: string) {
    const attempt = await this.prisma.examAttempt.findUnique({ where: { id: attemptId } });
    if (!attempt || attempt.userId !== userId) {
      throw new ForbiddenException('No permission');
    }
    if (attempt.status !== 'IN_PROGRESS') {
      throw new BadRequestException('Attempt already finished');
    }

    return this.prisma.examRecordDetail.upsert({
      where: { attemptId_questionId: { attemptId, questionId } },
      update: { answer, savedAt: new Date() },
      create: { attemptId, questionId, answer },
    });
  }

  private normalizeAnswer(input: string) {
    return input
      .split(',')
      .map((item) => item.trim())
      .filter(Boolean)
      .sort()
      .join(',');
  }

  async submit(attemptId: number, userId: number, forced = false) {
    const attempt = await this.prisma.examAttempt.findUnique({
      where: { id: attemptId },
      include: {
        exam: { include: { examQuestions: true } },
        details: { include: { question: true } },
      },
    });
    if (!attempt || attempt.userId !== userId) {
      throw new ForbiddenException('No permission');
    }
    if (attempt.status !== 'IN_PROGRESS') {
      return attempt;
    }

    let total = 0;
    for (const detail of attempt.details) {
      const expected = this.normalizeAnswer(detail.question.answer);
      const actual = this.normalizeAnswer(detail.answer ?? '');
      const isCorrect = expected === actual;
      const questionConfig = attempt.exam.examQuestions.find(
        (x: { questionId: number }) => x.questionId === detail.questionId,
      );
      const fullScore = questionConfig?.scoreOverride ?? detail.question.score;
      const score = isCorrect ? fullScore : 0;
      total += score;
      await this.prisma.examRecordDetail.update({
        where: { attemptId_questionId: { attemptId, questionId: detail.questionId } },
        data: { isCorrect, score },
      });
    }

    return this.prisma.examAttempt.update({
      where: { id: attemptId },
      data: {
        status: forced ? 'FORCED_SUBMITTED' : 'SUBMITTED',
        submittedAt: new Date(),
        score: total,
      },
    });
  }

  async result(attemptId: number, userId: number, role: 'ADMIN' | 'STUDENT') {
    const attempt = await this.prisma.examAttempt.findUnique({
      where: { id: attemptId },
      include: {
        exam: true,
        details: { include: { question: true } },
      },
    });
    if (!attempt) {
      throw new ForbiddenException('No permission');
    }
    if (role !== 'ADMIN' && attempt.userId !== userId) {
      throw new ForbiddenException('No permission');
    }
    return attempt;
  }

  async myExams(userId: number) {
    const now = new Date();
    const [publishedExams, attempts] = await Promise.all([
      this.prisma.exam.findMany({
        where: {
          OR: [
            { status: ExamStatus.PUBLISHED },
            { isPublished: true },
          ],
        },
        include: { examQuestions: true },
        orderBy: { id: 'desc' },
      }),
      this.prisma.examAttempt.findMany({
        where: { userId },
        include: {
          exam: true,
          details: { include: { question: true } },
        },
        orderBy: { id: 'desc' },
      }),
    ]);

    const attemptByExam = new Map(attempts.map((x) => [x.examId, x]));
    const available = publishedExams
      .filter((exam) => this.examAccessibleForUser(exam.allowedUserIds, userId))
      .map((exam) => {
        const attempt = attemptByExam.get(exam.id);
        const startReady = !exam.startsAt || now >= exam.startsAt;
        const notEnded = !exam.endsAt || now <= exam.endsAt;
        const canStart = !attempt && startReady && notEnded;
        const status = attempt
          ? attempt.status === 'IN_PROGRESS'
            ? 'ONGOING'
            : 'FINISHED'
          : startReady
            ? 'READY'
            : 'UPCOMING';
        return {
          examId: exam.id,
          title: exam.title,
          durationMinutes: exam.durationMinutes,
          startsAt: exam.startsAt,
          endsAt: exam.endsAt,
          questionCount: exam.examQuestions.length,
          canStart,
          status,
          attemptId: attempt?.id ?? null,
          score: attempt?.score ?? null,
        };
      });

    const history = attempts.map((attempt) => {
      const wrongCount = attempt.details.filter((d) => d.isCorrect === false).length;
      return {
        attemptId: attempt.id,
        examId: attempt.examId,
        title: attempt.exam.title,
        status: attempt.status,
        score: attempt.score,
        startedAt: attempt.startedAt,
        submittedAt: attempt.submittedAt,
        wrongCount,
      };
    });

    return { available, history };
  }

  async myWrongQuestions(userId: number, attemptId?: number) {
    const attempts = await this.prisma.examAttempt.findMany({
      where: {
        userId,
        ...(attemptId ? { id: attemptId } : {}),
        status: { in: ['SUBMITTED', 'FORCED_SUBMITTED'] },
      },
      include: {
        exam: true,
        details: {
          include: {
            question: true,
          },
        },
      },
      orderBy: { id: 'desc' },
    });
    const rows: Array<Record<string, unknown>> = [];
    for (const attempt of attempts) {
      for (const detail of attempt.details) {
        if (detail.isCorrect === false) {
          rows.push({
            attemptId: attempt.id,
            examId: attempt.examId,
            examTitle: attempt.exam.title,
            questionId: detail.questionId,
            questionType: detail.question.type,
            content: detail.question.content,
            options: detail.question.options,
            myAnswer: detail.answer,
            answer: detail.question.answer,
            score: detail.score ?? 0,
            fullScore: detail.question.score,
          });
        }
      }
    }
    return rows;
  }

  async antiCheatEvent(
    attemptId: number,
    userId: number,
    eventType: string,
    message?: string,
  ) {
    const attempt = await this.prisma.examAttempt.findUnique({ where: { id: attemptId } });
    if (!attempt || attempt.userId !== userId) {
      throw new ForbiddenException('No permission');
    }
    if (attempt.status !== 'IN_PROGRESS') {
      return { forcedSubmit: false, antiCheatViolationCount: attempt.antiCheatViolationCount };
    }

    const updated = await this.prisma.examAttempt.update({
      where: { id: attemptId },
      data: {
        antiCheatViolationCount: { increment: 1 },
        antiCheatEvents: {
          create: { eventType, message },
        },
      },
    });

    if (updated.antiCheatViolationCount >= 3) {
      await this.submit(attemptId, userId, true);
      return { forcedSubmit: true, antiCheatViolationCount: updated.antiCheatViolationCount };
    }
    return { forcedSubmit: false, antiCheatViolationCount: updated.antiCheatViolationCount };
  }
}
