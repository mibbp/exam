import {
  Body,
  Controller,
  Get,
  Param,
  ParseIntPipe,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { AttemptsService } from './attempts.service';
import { StartAttemptDto } from './dto/start-attempt.dto';
import { SaveAnswerDto } from './dto/save-answer.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { CurrentUser, JwtUser } from '../auth/decorators/current-user.decorator';

@Controller()
@UseGuards(JwtAuthGuard, RolesGuard)
export class AttemptsController {
  constructor(private readonly attemptsService: AttemptsService) {}

  @Post('attempts/start')
  @Roles('STUDENT')
  start(@Body() dto: StartAttemptDto, @CurrentUser() user: JwtUser) {
    return this.attemptsService.start(dto.examId, user.sub);
  }

  @Patch('attempts/:id/answers/:questionId')
  @Roles('STUDENT')
  saveAnswer(
    @Param('id', ParseIntPipe) attemptId: number,
    @Param('questionId', ParseIntPipe) questionId: number,
    @Body() dto: SaveAnswerDto,
    @CurrentUser() user: JwtUser,
  ) {
    return this.attemptsService.saveAnswer(attemptId, questionId, user.sub, dto.answer);
  }

  @Post('attempts/:id/submit')
  @Roles('STUDENT')
  submit(@Param('id', ParseIntPipe) attemptId: number, @CurrentUser() user: JwtUser) {
    return this.attemptsService.submit(attemptId, user.sub);
  }

  @Get('attempts/:id/result')
  @Roles('STUDENT', 'ADMIN')
  result(@Param('id', ParseIntPipe) attemptId: number, @CurrentUser() user: JwtUser) {
    return this.attemptsService.result(attemptId, user.sub, user.role);
  }

  @Get('my-exams')
  @Roles('STUDENT')
  myExams(@CurrentUser() user: JwtUser) {
    return this.attemptsService.myExams(user.sub);
  }

  @Get('my-wrong-questions')
  @Roles('STUDENT')
  myWrongQuestions(@CurrentUser() user: JwtUser, @Query('attemptId') attemptId?: string) {
    return this.attemptsService.myWrongQuestions(user.sub, attemptId ? Number(attemptId) : undefined);
  }

  @Post('anti-cheat/events')
  @Roles('STUDENT')
  antiCheat(
    @Body() body: { attemptId: number; eventType: string; message?: string },
    @CurrentUser() user: JwtUser,
  ) {
    return this.attemptsService.antiCheatEvent(
      body.attemptId,
      user.sub,
      body.eventType,
      body.message,
    );
  }
}
