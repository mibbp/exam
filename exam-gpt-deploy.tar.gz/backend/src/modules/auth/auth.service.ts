import {
  ForbiddenException,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../../prisma/prisma.service';
import * as bcrypt from 'bcrypt';

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
  ) {}

  async login(username: string, password: string, userAgent?: string, ip?: string) {
    const user = await this.prisma.user.findUnique({ where: { username } });
    if (!user) {
      throw new UnauthorizedException('Invalid credentials');
    }
    if (user.status === 'DISABLED') {
      throw new UnauthorizedException('User disabled');
    }
    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) {
      throw new UnauthorizedException('Invalid credentials');
    }

    const accessToken = await this.jwtService.signAsync(
      { sub: user.id, username: user.username, role: user.role },
      {
        secret: process.env.JWT_ACCESS_SECRET ?? 'access-secret',
        expiresIn: '45m',
      },
    );

    const refreshToken = await this.jwtService.signAsync(
      { sub: user.id, username: user.username, role: user.role, type: 'refresh' },
      {
        secret: process.env.JWT_REFRESH_SECRET ?? 'refresh-secret',
        expiresIn: '7d',
      },
    );

    const refreshHash = await bcrypt.hash(refreshToken, 10);
    await this.prisma.refreshSession.create({
      data: {
        userId: user.id,
        tokenHash: refreshHash,
        userAgent,
        ipAddress: ip,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });
    await this.prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    return {
      accessToken,
      refreshToken,
      user: {
        id: user.id,
        username: user.username,
        displayName: user.displayName,
        role: user.role,
        status: user.status,
      },
    };
  }

  async refresh(oldRefreshToken: string, userAgent?: string, ip?: string) {
    const payload = await this.jwtService
      .verifyAsync<{ sub: number; username: string; role: 'ADMIN' | 'STUDENT'; type: string }>(oldRefreshToken, {
        secret: process.env.JWT_REFRESH_SECRET ?? 'refresh-secret',
      })
      .catch(() => null);

    if (!payload || payload.type !== 'refresh') {
      throw new UnauthorizedException('Invalid refresh token');
    }

    const sessions = await this.prisma.refreshSession.findMany({
      where: {
        userId: payload.sub,
        revokedAt: null,
        expiresAt: { gt: new Date() },
      },
    });

    let currentSessionId: number | null = null;
    for (const session of sessions) {
      const matched = await bcrypt.compare(oldRefreshToken, session.tokenHash);
      if (matched) {
        currentSessionId = session.id;
        break;
      }
    }

    if (!currentSessionId) {
      throw new ForbiddenException('Refresh session not found');
    }

    await this.prisma.refreshSession.update({
      where: { id: currentSessionId },
      data: { revokedAt: new Date() },
    });

    const accessToken = await this.jwtService.signAsync(
      { sub: payload.sub, username: payload.username, role: payload.role },
      {
        secret: process.env.JWT_ACCESS_SECRET ?? 'access-secret',
        expiresIn: '45m',
      },
    );
    const refreshToken = await this.jwtService.signAsync(
      {
        sub: payload.sub,
        username: payload.username,
        role: payload.role,
        type: 'refresh',
      },
      {
        secret: process.env.JWT_REFRESH_SECRET ?? 'refresh-secret',
        expiresIn: '7d',
      },
    );
    const refreshHash = await bcrypt.hash(refreshToken, 10);
    await this.prisma.refreshSession.create({
      data: {
        userId: payload.sub,
        tokenHash: refreshHash,
        userAgent,
        ipAddress: ip,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });

    return { accessToken, refreshToken };
  }

  async logout(refreshToken: string) {
    const sessions = await this.prisma.refreshSession.findMany({
      where: { revokedAt: null, expiresAt: { gt: new Date() } },
    });
    for (const session of sessions) {
      const matched = await bcrypt.compare(refreshToken, session.tokenHash);
      if (matched) {
        await this.prisma.refreshSession.update({
          where: { id: session.id },
          data: { revokedAt: new Date() },
        });
        break;
      }
    }
    return { ok: true };
  }
}
