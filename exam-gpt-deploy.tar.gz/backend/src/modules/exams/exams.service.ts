import { BadRequestException, ForbiddenException, Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateExamDto } from './dto/create-exam.dto';
import { UpdateExamDto } from './dto/update-exam.dto';
import type { JwtUser } from '../auth/decorators/current-user.decorator';
import { ListExamsDto } from './dto/list-exams.dto';
import { ExamStatus } from '@prisma/client';

@Injectable()
export class ExamsService {
  constructor(private readonly prisma: PrismaService) {}

  private async assertQuestionConfigs(questionConfigs: Array<{ questionId: number }>) {
    const ids = questionConfigs.map((x) => x.questionId);
    const uniqueIds = Array.from(new Set(ids));
    if (uniqueIds.length !== ids.length) {
      throw new BadRequestException('Duplicate question in exam');
    }
    const exists = await this.prisma.question.count({
      where: { id: { in: uniqueIds } },
    });
    if (exists !== uniqueIds.length) {
      throw new BadRequestException('Some questions do not exist');
    }
  }

  async create(dto: CreateExamDto) {
    await this.assertQuestionConfigs(dto.questionConfigs);
    return this.prisma.exam.create({
      data: {
        title: dto.title,
        description: dto.description,
        durationMinutes: dto.durationMinutes,
        startsAt: dto.startsAt ? new Date(dto.startsAt) : null,
        endsAt: dto.endsAt ? new Date(dto.endsAt) : null,
        status: ExamStatus.DRAFT,
        isPublished: false,
        allowedUserIds: dto.allowedUserIds ?? [],
        examQuestions: {
          create: dto.questionConfigs.map((q, idx) => ({
            questionId: q.questionId,
            orderNo: idx + 1,
            scoreOverride: q.score,
          })),
        },
      },
      include: { examQuestions: true },
    });
  }

  async update(id: number, dto: UpdateExamDto) {
    const existing = await this.prisma.exam.findUnique({ where: { id } });
    if (!existing) {
      throw new BadRequestException('Exam not found');
    }
    if (existing.status === ExamStatus.CLOSED) {
      throw new BadRequestException('Closed exam cannot be edited');
    }
    if (dto.questionConfigs && dto.questionConfigs.length > 0) {
      await this.assertQuestionConfigs(dto.questionConfigs);
    }
    return this.prisma.exam.update({
      where: { id },
      data: {
        ...(dto.title !== undefined ? { title: dto.title } : {}),
        ...(dto.description !== undefined ? { description: dto.description } : {}),
        ...(dto.durationMinutes !== undefined ? { durationMinutes: dto.durationMinutes } : {}),
        ...(dto.startsAt !== undefined ? { startsAt: dto.startsAt ? new Date(dto.startsAt) : null } : {}),
        ...(dto.endsAt !== undefined ? { endsAt: dto.endsAt ? new Date(dto.endsAt) : null } : {}),
        ...(dto.allowedUserIds !== undefined ? { allowedUserIds: dto.allowedUserIds } : {}),
        ...(dto.questionConfigs
          ? {
              examQuestions: {
                deleteMany: {},
                create: dto.questionConfigs.map((q, idx) => ({
                  questionId: q.questionId,
                  orderNo: idx + 1,
                  scoreOverride: q.score,
                })),
              },
            }
          : {}),
      },
      include: { examQuestions: true },
    });
  }

  async findAll(user: JwtUser, query: ListExamsDto) {
    const page = query.page ?? 1;
    const pageSize = Math.min(query.pageSize ?? 20, 100);

    const commonWhere = {
      ...(query.keyword ? { title: { contains: query.keyword } } : {}),
      ...(query.status ? { status: query.status } : {}),
      ...(query.dateFrom ? { createdAt: { gte: new Date(query.dateFrom) } } : {}),
      ...(query.dateTo ? { createdAt: { lte: new Date(query.dateTo) } } : {}),
    };

    const where =
      user.role === 'ADMIN'
        ? commonWhere
        : {
            ...commonWhere,
            OR: [
              { status: ExamStatus.PUBLISHED },
              { isPublished: true },
            ],
          };

    const [total, rows] = await Promise.all([
      this.prisma.exam.count({ where }),
      this.prisma.exam.findMany({
        where,
        orderBy: { id: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: {
          examQuestions: true,
          _count: { select: { attempts: true } },
        },
      }),
    ]);

    const filteredRows =
      user.role === 'ADMIN'
        ? rows
        : rows.filter((row) => {
            const allowed = row.allowedUserIds as unknown;
            if (!Array.isArray(allowed) || allowed.length === 0) return true;
            return allowed.includes(user.sub);
          });

    return {
      total: user.role === 'ADMIN' ? total : filteredRows.length,
      page,
      pageSize,
      rows: filteredRows,
    };
  }

  async findOne(id: number, user: JwtUser) {
    const exam = await this.prisma.exam.findUnique({
      where: { id },
      include: {
        examQuestions: { include: { question: true }, orderBy: { orderNo: 'asc' } },
        _count: { select: { attempts: true } },
      },
    });
    if (!exam) {
      throw new BadRequestException('Exam not found');
    }
    if (user.role !== 'ADMIN') {
      if (exam.status !== ExamStatus.PUBLISHED && !exam.isPublished) {
        throw new ForbiddenException('No permission');
      }
      const allowed = exam.allowedUserIds as unknown;
      if (Array.isArray(allowed) && allowed.length > 0 && !allowed.includes(user.sub)) {
        throw new ForbiddenException('No permission');
      }
    }
    if (user.role !== 'ADMIN') {
      return {
        ...exam,
        examQuestions: exam.examQuestions.map((eq) => ({
          ...eq,
          question: {
            ...eq.question,
            answer: '',
          },
        })),
      };
    }
    return exam;
  }

  async publish(id: number) {
    return this.prisma.exam.update({
      where: { id },
      data: {
        status: ExamStatus.PUBLISHED,
        isPublished: true,
      },
    });
  }

  async unpublish(id: number) {
    return this.prisma.exam.update({
      where: { id },
      data: {
        status: ExamStatus.DRAFT,
        isPublished: false,
      },
    });
  }

  async close(id: number) {
    return this.prisma.exam.update({
      where: { id },
      data: {
        status: ExamStatus.CLOSED,
        isPublished: false,
      },
    });
  }

  async remove(id: number) {
    await this.prisma.exam.delete({ where: { id } });
    return { ok: true };
  }

  async scoreboard(examId: number, page = 1, pageSize = 20, keyword?: string) {
    const where = {
      examId,
      ...(keyword
        ? {
            user: {
              OR: [
                { username: { contains: keyword } },
                { displayName: { contains: keyword } },
              ],
            },
          }
        : {}),
    };
    const [total, rows] = await Promise.all([
      this.prisma.examAttempt.count({ where }),
      this.prisma.examAttempt.findMany({
        where,
        orderBy: { id: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: {
          user: true,
        },
      }),
    ]);
    return {
      total,
      page,
      pageSize,
      rows: rows.map((r) => ({
        id: r.id,
        userId: r.userId,
        username: r.user.username,
        displayName: r.user.displayName,
        status: r.status,
        score: r.score,
        startedAt: r.startedAt,
        submittedAt: r.submittedAt,
        antiCheatViolationCount: r.antiCheatViolationCount,
      })),
    };
  }
}
