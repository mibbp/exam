import { Body, Controller, Delete, Get, Param, ParseIntPipe, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { ExamsService } from './exams.service';
import { CreateExamDto } from './dto/create-exam.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { CurrentUser, JwtUser } from '../auth/decorators/current-user.decorator';
import { UpdateExamDto } from './dto/update-exam.dto';
import { ListExamsDto } from './dto/list-exams.dto';

@Controller('exams')
@UseGuards(JwtAuthGuard, RolesGuard)
export class ExamsController {
  constructor(private readonly examsService: ExamsService) {}

  @Get()
  @Roles('ADMIN', 'STUDENT')
  findAll(@CurrentUser() user: JwtUser, @Query() query: ListExamsDto) {
    return this.examsService.findAll(user, query);
  }

  @Get(':id')
  @Roles('ADMIN', 'STUDENT')
  findOne(@Param('id', ParseIntPipe) id: number, @CurrentUser() user: JwtUser) {
    return this.examsService.findOne(id, user);
  }

  @Post()
  @Roles('ADMIN')
  create(@Body() dto: CreateExamDto) {
    return this.examsService.create(dto);
  }

  @Patch(':id')
  @Roles('ADMIN')
  update(@Param('id', ParseIntPipe) id: number, @Body() dto: UpdateExamDto) {
    return this.examsService.update(id, dto);
  }

  @Post(':id/publish')
  @Roles('ADMIN')
  publish(@Param('id', ParseIntPipe) id: number) {
    return this.examsService.publish(id);
  }

  @Post(':id/unpublish')
  @Roles('ADMIN')
  unpublish(@Param('id', ParseIntPipe) id: number) {
    return this.examsService.unpublish(id);
  }

  @Post(':id/close')
  @Roles('ADMIN')
  close(@Param('id', ParseIntPipe) id: number) {
    return this.examsService.close(id);
  }

  @Delete(':id')
  @Roles('ADMIN')
  remove(@Param('id', ParseIntPipe) id: number) {
    return this.examsService.remove(id);
  }

  @Get(':id/scoreboard')
  @Roles('ADMIN')
  scoreboard(
    @Param('id', ParseIntPipe) id: number,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
    @Query('keyword') keyword?: string,
  ) {
    return this.examsService.scoreboard(id, Number(page || 1), Number(pageSize || 20), keyword);
  }
}

