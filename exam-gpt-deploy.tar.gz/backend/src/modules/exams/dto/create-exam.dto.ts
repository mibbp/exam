import { Type } from 'class-transformer';
import { ArrayMinSize, IsArray, IsInt, IsOptional, IsString, Min, ValidateNested } from 'class-validator';

export class ExamQuestionConfigDto {
  @Type(() => Number)
  @IsInt()
  questionId!: number;

  @Type(() => Number)
  @IsInt()
  @Min(1)
  score!: number;
}

export class CreateExamDto {
  @IsString()
  title!: string;

  @IsOptional()
  @IsString()
  description?: string;

  @Type(() => Number)
  @IsInt()
  @Min(1)
  durationMinutes!: number;

  @IsOptional()
  @IsString()
  startsAt?: string;

  @IsOptional()
  @IsString()
  endsAt?: string;

  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => ExamQuestionConfigDto)
  questionConfigs!: ExamQuestionConfigDto[];

  @IsOptional()
  @IsArray()
  allowedUserIds?: number[];
}

