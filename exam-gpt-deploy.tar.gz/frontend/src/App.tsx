import { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  App as AntApp,
  Button,
  Card,
  Col,
  Divider,
  Drawer,
  Empty,
  Form,
  Input,
  InputNumber,
  Layout,
  List,
  Modal,
  Popconfirm,
  Row,
  Select,
  Space,
  Table,
  Tabs,
  Tag,
  Typography,
  Upload,
} from 'antd';
import type { UploadProps } from 'antd';
import {
  closeExam,
  createExam,
  createQuestion,
  createUser,
  deleteExam,
  examAnalytics,
  examScoreboard,
  getAttemptResult,
  getExam,
  importQuestions,
  listExams,
  listMyExams,
  listMyWrongQuestions,
  listQuestions,
  listUsers,
  login,
  logout,
  publishExam,
  resetUserPassword,
  saveAnswer,
  startAttempt,
  submitAttempt,
  unpublishExam,
  updateExam,
  updateQuestion,
  updateUser,
} from './api/services';
import { clearAuthState, getAuthState, setAuthState } from './api/auth-store';
import type {
  AuthUser,
  Exam,
  ExamScoreboardRow,
  MyExamAvailable,
  MyExamHistory,
  PagedResult,
  Question,
  UserRow,
  WrongQuestion,
} from './types';

const { Header, Content } = Layout;

function parseCommaValues(raw: string): string[] {
  const normalized = String(raw ?? '').split(String.fromCharCode(65292)).join(',');
  return normalized.split(',').map((item) => item.trim()).filter(Boolean);
}

function normalizeAnswer(raw: string): string {
  return String(raw ?? '').split(String.fromCharCode(65292)).join(',').replace(/\s+/g, '');
}

function useAuth() {
  const [version, setVersion] = useState(0);
  const state = getAuthState();
  return {
    ...state,
    setAuth(next: { accessToken: string | null; user: AuthUser | null }) {
      setAuthState(next);
      setVersion((v) => v + 1);
    },
    clear() {
      clearAuthState();
      setVersion((v) => v + 1);
    },
    version,
  };
}

function LoginView({ onLogin }: { onLogin: () => void }) {
  const [loading, setLoading] = useState(false);
  const { message } = AntApp.useApp();

  return (
    <Layout className="min-h-screen">
      <Content className="flex items-center justify-center p-6">
        <Card title="在线考试系统登录" className="w-full max-w-md shadow-lg" bordered={false}>
          <Form
            layout="vertical"
            onFinish={async (values) => {
              try {
                setLoading(true);
                const data = await login(values.username, values.password);
                setAuthState({ accessToken: data.accessToken, user: data.user });
                message.success('登录成功');
                onLogin();
              } catch {
                message.error('用户名或密码错误');
              } finally {
                setLoading(false);
              }
            }}
          >
            <Form.Item label="用户名" name="username" rules={[{ required: true }]}>
              <Input placeholder="admin / student / student1" />
            </Form.Item>
            <Form.Item label="密码" name="password" rules={[{ required: true }]}>
              <Input.Password placeholder="默认: Admin@123 / Student@123" />
            </Form.Item>
            <Button htmlType="submit" type="primary" block loading={loading}>
              登录
            </Button>
          </Form>
        </Card>
      </Content>
    </Layout>
  );
}

function QuestionManagement() {
  const { message } = AntApp.useApp();
  const [list, setList] = useState<PagedResult<Question>>({ total: 0, page: 1, pageSize: 20, rows: [] });
  const [loading, setLoading] = useState(false);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<Question | null>(null);
  const [keyword, setKeyword] = useState('');
  const [form] = Form.useForm();

  const load = async (page = 1, pageSize = 20) => {
    setLoading(true);
    try {
      setList(await listQuestions({ page, pageSize, keyword: keyword || undefined }));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  const uploadProps: UploadProps = {
    beforeUpload: async (file) => {
      const result = await importQuestions(file as File);
      message.success(`导入完成：${result.successCount}/${result.total}`);
      await load(list.page, list.pageSize);
      return false;
    },
    showUploadList: false,
  };

  return (
    <Card title="题库管理" bordered={false}>
      <Space style={{ marginBottom: 12 }} wrap>
        <Input placeholder="题目关键字" style={{ width: 240 }} value={keyword} onChange={(e) => setKeyword(e.target.value)} />
        <Button type="primary" onClick={() => void load(1, list.pageSize)}>查询</Button>
        <Button onClick={() => { setEditing(null); form.resetFields(); form.setFieldsValue({ type: 'SINGLE', score: 2, difficulty: 1 }); setEditorOpen(true); }}>新增题目</Button>
        <Upload {...uploadProps}><Button>批量导入</Button></Upload>
      </Space>

      <Table
        rowKey="id"
        loading={loading}
        dataSource={list.rows}
        columns={[
          { title: 'ID', dataIndex: 'id', width: 80 },
          { title: '题型', dataIndex: 'type', width: 120 },
          { title: '题目', dataIndex: 'content' },
          { title: '答案', dataIndex: 'answer', width: 120 },
          { title: '分值', dataIndex: 'score', width: 90 },
          {
            title: '操作',
            width: 100,
            render: (_, row) => <Button type="link" onClick={() => { setEditing(row); form.setFieldsValue({ ...row, optionsText: row.options.join(',') }); setEditorOpen(true); }}>编辑</Button>,
          },
        ]}
        pagination={{ current: list.page, pageSize: list.pageSize, total: list.total, onChange: (p, ps) => void load(p, ps) }}
      />

      <Drawer open={editorOpen} onClose={() => setEditorOpen(false)} title={editing ? '编辑题目' : '新增题目'} width={560}>
        <Form
          form={form}
          layout="vertical"
          onFinish={async (values) => {
            const payload = {
              type: values.type,
              content: values.content,
              options: parseCommaValues(values.optionsText),
              answer: normalizeAnswer(values.answer),
              score: values.score,
              difficulty: values.difficulty,
              analysis: values.analysis,
            };
            if (editing) {
              await updateQuestion(editing.id, payload);
              message.success('更新成功');
            } else {
              await createQuestion(payload);
              message.success('新增成功');
            }
            setEditorOpen(false);
            await load(list.page, list.pageSize);
          }}
        >
          <Form.Item name="type" label="题型" rules={[{ required: true }]}>
            <Select options={[{ label: '单选', value: 'SINGLE' }, { label: '多选', value: 'MULTIPLE' }, { label: '判断', value: 'TRUE_FALSE' }]} />
          </Form.Item>
          <Form.Item name="content" label="题目" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="optionsText" label="选项（中英文逗号均可）" rules={[{ required: true }]}><Input /></Form.Item>
          <Row gutter={12}>
            <Col span={12}><Form.Item name="answer" label="答案" rules={[{ required: true }]}><Input /></Form.Item></Col>
            <Col span={6}><Form.Item name="score" label="分值" rules={[{ required: true }]}><InputNumber min={1} style={{ width: '100%' }} /></Form.Item></Col>
            <Col span={6}><Form.Item name="difficulty" label="难度" rules={[{ required: true }]}><InputNumber min={1} max={5} style={{ width: '100%' }} /></Form.Item></Col>
          </Row>
          <Form.Item name="analysis" label="解析"><Input.TextArea rows={4} /></Form.Item>
          <Space>
            <Button onClick={() => setEditorOpen(false)}>取消</Button>
            <Button htmlType="submit" type="primary">保存</Button>
          </Space>
        </Form>
      </Drawer>
    </Card>
  );
}

function ExamManagement() {
  const { message } = AntApp.useApp();
  const [list, setList] = useState<PagedResult<Exam>>({ total: 0, page: 1, pageSize: 20, rows: [] });
  const [loading, setLoading] = useState(false);
  const [keyword, setKeyword] = useState('');
  const [status, setStatus] = useState<string | undefined>(undefined);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [selectedQuestionIds, setSelectedQuestionIds] = useState<number[]>([]);
  const [scores, setScores] = useState<Record<number, number>>({});
  const [openEditor, setOpenEditor] = useState(false);
  const [editing, setEditing] = useState<Exam | null>(null);
  const [form] = Form.useForm();
  const [stats, setStats] = useState<Record<number, { totalAttempts: number; avgScore: number }>>({});
  const [scoreboardOpen, setScoreboardOpen] = useState(false);
  const [scoreboardRows, setScoreboardRows] = useState<PagedResult<ExamScoreboardRow>>({ total: 0, page: 1, pageSize: 20, rows: [] });
  const [scoreboardExam, setScoreboardExam] = useState<Exam | null>(null);

  const load = async (page = 1, pageSize = 20) => {
    setLoading(true);
    try {
      const data = await listExams({ page, pageSize, keyword: keyword || undefined, status });
      setList(data);
      const m: Record<number, { totalAttempts: number; avgScore: number }> = {};
      await Promise.all(data.rows.map(async (e) => { const s = await examAnalytics(e.id); m[e.id] = { totalAttempts: s.totalAttempts, avgScore: s.avgScore }; }));
      setStats(m);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
    void (async () => setQuestions((await listQuestions({ page: 1, pageSize: 300 })).rows))();
  }, []);

  return (
    <Card title="考试管理" bordered={false}>
      <Space style={{ marginBottom: 12 }} wrap>
        <Input placeholder="考试标题" style={{ width: 220 }} value={keyword} onChange={(e) => setKeyword(e.target.value)} />
        <Select allowClear placeholder="状态" style={{ width: 140 }} value={status} onChange={setStatus} options={[{ label: '草稿', value: 'DRAFT' }, { label: '已发布', value: 'PUBLISHED' }, { label: '已关闭', value: 'CLOSED' }]} />
        <Button type="primary" onClick={() => void load(1, list.pageSize)}>查询</Button>
        <Button onClick={() => { setEditing(null); setSelectedQuestionIds([]); setScores({}); form.resetFields(); form.setFieldsValue({ durationMinutes: 60 }); setOpenEditor(true); }}>新增考试</Button>
      </Space>

      <Table
        rowKey="id"
        loading={loading}
        dataSource={list.rows}
        columns={[
          { title: 'ID', dataIndex: 'id', width: 70 },
          { title: '标题', dataIndex: 'title' },
          { title: '题量', render: (_, r) => r.examQuestions.length, width: 80 },
          { title: '状态', render: (_, r) => <Tag color={r.status === 'PUBLISHED' ? 'green' : r.status === 'CLOSED' ? 'red' : 'gold'}>{r.status}</Tag>, width: 120 },
          { title: '参考人数', render: (_, r) => stats[r.id]?.totalAttempts ?? 0, width: 100 },
          { title: '平均分', render: (_, r) => (stats[r.id]?.avgScore ?? 0).toFixed(2), width: 100 },
          {
            title: '操作',
            width: 350,
            render: (_, row) => (
              <Space size={4} wrap>
                <Button size="small" onClick={async () => { const d = await getExam(row.id); setEditing(d); const ids = d.examQuestions.map((x) => x.questionId); const map: Record<number, number> = {}; d.examQuestions.forEach((x) => { map[x.questionId] = x.scoreOverride ?? 1; }); setSelectedQuestionIds(ids); setScores(map); form.setFieldsValue(d); setOpenEditor(true); }}>编辑</Button>
                <Button size="small" onClick={async () => { setScoreboardExam(row); setScoreboardRows(await examScoreboard(row.id)); setScoreboardOpen(true); }}>成绩</Button>
                {row.status !== 'PUBLISHED' && <Button size="small" type="primary" onClick={async () => { await publishExam(row.id); await load(list.page, list.pageSize); }}>发布</Button>}
                {row.status === 'PUBLISHED' && <Button size="small" onClick={async () => { await unpublishExam(row.id); await load(list.page, list.pageSize); }}>撤回</Button>}
                {row.status !== 'CLOSED' && <Button size="small" danger onClick={async () => { await closeExam(row.id); await load(list.page, list.pageSize); }}>关闭</Button>}
                <Popconfirm title="确认删除考试？" onConfirm={async () => { await deleteExam(row.id); message.success('删除成功'); await load(list.page, list.pageSize); }}><Button size="small" danger>删除</Button></Popconfirm>
              </Space>
            ),
          },
        ]}
        pagination={{ current: list.page, pageSize: list.pageSize, total: list.total, onChange: (p, ps) => void load(p, ps) }}
      />

      <Drawer open={openEditor} onClose={() => setOpenEditor(false)} title={editing ? '编辑考试' : '新增考试'} width={900}>
        <Form
          form={form}
          layout="vertical"
          onFinish={async (values) => {
            const questionConfigs = selectedQuestionIds.map((id) => ({ questionId: id, score: scores[id] || 1 }));
            if (questionConfigs.length === 0) {
              message.error('请至少选择一题');
              return;
            }
            const payload = {
              title: values.title,
              description: values.description,
              durationMinutes: values.durationMinutes,
              startsAt: values.startsAt,
              endsAt: values.endsAt,
              questionConfigs,
            };
            if (editing) {
              await updateExam(editing.id, payload);
              message.success('考试更新成功');
            } else {
              await createExam(payload);
              message.success('考试创建成功');
            }
            setOpenEditor(false);
            await load(list.page, list.pageSize);
          }}
        >
          <Row gutter={12}>
            <Col span={12}><Form.Item name="title" label="标题" rules={[{ required: true }]}><Input /></Form.Item></Col>
            <Col span={6}><Form.Item name="durationMinutes" label="时长(分钟)" rules={[{ required: true }]}><InputNumber min={1} style={{ width: '100%' }} /></Form.Item></Col>
          </Row>
          <Form.Item name="description" label="说明"><Input.TextArea rows={2} /></Form.Item>
          <Row gutter={12}>
            <Col span={12}><Form.Item name="startsAt" label="开始时间(ISO)"><Input /></Form.Item></Col>
            <Col span={12}><Form.Item name="endsAt" label="结束时间(ISO)"><Input /></Form.Item></Col>
          </Row>
          <Form.Item label="组题（可配置分值）">
            <Select mode="multiple" value={selectedQuestionIds} style={{ width: '100%' }} onChange={(vals) => { setSelectedQuestionIds(vals); setScores((prev) => { const next = { ...prev }; vals.forEach((id) => { if (!next[id]) next[id] = 1; }); return next; }); }} options={questions.map((q) => ({ label: `${q.id}. ${q.content}`, value: q.id }))} />
          </Form.Item>
          <Space direction="vertical" style={{ width: '100%' }}>
            {selectedQuestionIds.map((id: number, idx: number) => (
              <Row key={id} gutter={8}>
                <Col span={18}><Typography.Text>{idx + 1}. {questions.find((q) => q.id === id)?.content || `题目${id}`}</Typography.Text></Col>
                <Col span={6}><InputNumber min={1} style={{ width: '100%' }} value={scores[id] || 1} onChange={(v) => setScores((prev) => ({ ...prev, [id]: Number(v || 1) }))} /></Col>
              </Row>
            ))}
          </Space>
          <Divider />
          <Space><Button onClick={() => setOpenEditor(false)}>取消</Button><Button htmlType="submit" type="primary">保存</Button></Space>
        </Form>
      </Drawer>

      <Drawer open={scoreboardOpen} onClose={() => setScoreboardOpen(false)} title={`成绩单 - ${scoreboardExam?.title || ''}`} width={860}>
        <Table
          rowKey="id"
          dataSource={scoreboardRows.rows}
          columns={[
            { title: '姓名', render: (_, r) => r.displayName || r.username },
            { title: '账号', dataIndex: 'username' },
            { title: '状态', dataIndex: 'status' },
            { title: '分数', dataIndex: 'score' },
            { title: '开始时间', dataIndex: 'startedAt' },
            { title: '提交时间', dataIndex: 'submittedAt' },
          ]}
          pagination={{ current: scoreboardRows.page, pageSize: scoreboardRows.pageSize, total: scoreboardRows.total }}
        />
      </Drawer>
    </Card>
  );
}

function UserManagement() {
  const { message } = AntApp.useApp();
  const [list, setList] = useState<PagedResult<UserRow>>({ total: 0, page: 1, pageSize: 20, rows: [] });
  const [openEditor, setOpenEditor] = useState(false);
  const [editing, setEditing] = useState<UserRow | null>(null);
  const [form] = Form.useForm();

  const load = async () => setList(await listUsers({ page: 1, pageSize: 50 }));
  useEffect(() => { void load(); }, []);

  return (
    <Card title="权限管理" bordered={false}>
      <Space style={{ marginBottom: 12 }}>
        <Button onClick={() => { setEditing(null); form.resetFields(); form.setFieldsValue({ role: 'STUDENT', status: 'ACTIVE' }); setOpenEditor(true); }}>新增用户</Button>
      </Space>
      <Table
        rowKey="id"
        dataSource={list.rows}
        columns={[
          { title: 'ID', dataIndex: 'id', width: 80 },
          { title: '账号', dataIndex: 'username' },
          { title: '姓名', dataIndex: 'displayName' },
          { title: '角色', dataIndex: 'role', width: 100 },
          { title: '状态', dataIndex: 'status', width: 100 },
          {
            title: '操作',
            width: 240,
            render: (_, row) => (
              <Space>
                <Button size="small" onClick={() => { setEditing(row); form.setFieldsValue(row); setOpenEditor(true); }}>编辑</Button>
                <Button size="small" onClick={async () => { await resetUserPassword(row.id, 'Student@123'); message.success('已重置为 Student@123'); }}>重置密码</Button>
              </Space>
            ),
          },
        ]}
      />

      <Modal open={openEditor} onCancel={() => setOpenEditor(false)} onOk={() => form.submit()} title={editing ? '编辑用户' : '新增用户'}>
        <Form
          form={form}
          layout="vertical"
          onFinish={async (values) => {
            if (editing) {
              await updateUser(editing.id, { displayName: values.displayName, role: values.role, status: values.status });
            } else {
              await createUser({ username: values.username, password: values.password, displayName: values.displayName, role: values.role, status: values.status });
            }
            setOpenEditor(false);
            await load();
          }}
        >
          {!editing && <Form.Item name="username" label="账号" rules={[{ required: true }]}><Input /></Form.Item>}
          {!editing && <Form.Item name="password" label="初始密码" rules={[{ required: true, min: 6 }]}><Input.Password /></Form.Item>}
          <Form.Item name="displayName" label="姓名"><Input /></Form.Item>
          <Form.Item name="role" label="角色" rules={[{ required: true }]}><Select options={[{ label: '管理员', value: 'ADMIN' }, { label: '学生', value: 'STUDENT' }]} /></Form.Item>
          <Form.Item name="status" label="状态" rules={[{ required: true }]}><Select options={[{ label: '启用', value: 'ACTIVE' }, { label: '禁用', value: 'DISABLED' }]} /></Form.Item>
        </Form>
      </Modal>
    </Card>
  );
}

function AdminView() {
  return <Tabs defaultActiveKey="exams" items={[{ key: 'exams', label: '考试管理', children: <ExamManagement /> }, { key: 'questions', label: '题库管理', children: <QuestionManagement /> }, { key: 'users', label: '权限管理', children: <UserManagement /> }]} />;
}

function StudentView() {
  const { message } = AntApp.useApp();
  const [hall, setHall] = useState<MyExamAvailable[]>([]);
  const [history, setHistory] = useState<MyExamHistory[]>([]);
  const [wrongList, setWrongList] = useState<WrongQuestion[]>([]);
  const [wrongOpen, setWrongOpen] = useState(false);
  const [activeAttemptId, setActiveAttemptId] = useState<number | null>(null);
  const [activeExam, setActiveExam] = useState<any>(null);
  const [answers, setAnswers] = useState<Record<number, string>>({});

  const load = async () => {
    const d = await listMyExams();
    setHall(d.available);
    setHistory(d.history);
  };
  useEffect(() => { void load(); }, []);

  const examQuestions = useMemo<Question[]>(
    () => (activeExam ? activeExam.examQuestions.map((x: any) => x.question as Question) : []),
    [activeExam],
  );

  useEffect(() => {
    if (!activeAttemptId) return;
    const h = window.setTimeout(async () => {
      await Promise.all(Object.entries(answers).map(([qid, ans]) => saveAnswer(activeAttemptId, Number(qid), ans)));
    }, 400);
    return () => window.clearTimeout(h);
  }, [answers, activeAttemptId]);

  if (activeAttemptId && activeExam) {
    return (
      <Space direction="vertical" style={{ width: '100%' }}>
        <Alert type="warning" message="考试过程中请勿切屏，累计 3 次将强制交卷。" showIcon />
        <Card title={activeExam.title} bordered={false}>
          <Space direction="vertical" style={{ width: '100%' }}>
            {examQuestions.map((q: Question, idx: number) => (
              <Card key={q.id} type="inner" title={`${idx + 1}. ${q.content}`}>
                <Select
                  mode={q.type === 'MULTIPLE' ? 'multiple' : undefined}
                  style={{ width: '100%' }}
                  value={q.type === 'MULTIPLE' ? (answers[q.id] ? answers[q.id].split(',') : []) : answers[q.id]}
                  onChange={(v) => {
                    const val = Array.isArray(v) ? v.join(',') : String(v ?? '');
                    setAnswers((prev) => ({ ...prev, [q.id]: val }));
                  }}
                  options={q.options.map((text: string, i: number) => ({ label: `${String.fromCharCode(65 + i)}. ${text}`, value: String.fromCharCode(65 + i) }))}
                />
              </Card>
            ))}
            <Space>
              <Button onClick={() => { setActiveAttemptId(null); setActiveExam(null); }}>返回</Button>
              <Button type="primary" onClick={async () => { await submitAttempt(activeAttemptId); const r = await getAttemptResult(activeAttemptId); Modal.success({ title: '交卷完成', content: `得分：${r.score ?? 0}` }); setActiveAttemptId(null); setActiveExam(null); await load(); }}>提交试卷</Button>
            </Space>
          </Space>
        </Card>
      </Space>
    );
  }

  return (
    <Tabs
      defaultActiveKey="hall"
      items={[
        {
          key: 'hall',
          label: '考试大厅',
          children: hall.length === 0 ? <Empty description="暂无考试" /> : (
            <Space direction="vertical" style={{ width: '100%' }}>
              {hall.map((e) => (
                <Card key={e.examId} bordered={false}>
                  <Row justify="space-between" align="middle">
                    <Col>
                      <Typography.Title level={5} style={{ marginBottom: 8 }}>{e.title}</Typography.Title>
                      <Space>
                        <Tag>{e.status}</Tag>
                        <Tag>时长 {e.durationMinutes} 分钟</Tag>
                        <Tag>题量 {e.questionCount}</Tag>
                      </Space>
                    </Col>
                    <Col>
                      {e.canStart && <Button type="primary" onClick={async () => { try { const start = await startAttempt(e.examId); setActiveAttemptId(start.id); setActiveExam(await getExam(e.examId)); message.success('考试已开始'); } catch { message.error('当前考试不可开始'); } }}>开始考试</Button>}
                    </Col>
                  </Row>
                </Card>
              ))}
            </Space>
          ),
        },
        {
          key: 'mine',
          label: '我的考试',
          children: (
            <Card bordered={false}>
              <Table
                rowKey="attemptId"
                dataSource={history}
                columns={[
                  { title: '考试', dataIndex: 'title' },
                  { title: '状态', dataIndex: 'status' },
                  { title: '分数', dataIndex: 'score' },
                  { title: '错题数', dataIndex: 'wrongCount' },
                  { title: '提交时间', dataIndex: 'submittedAt' },
                  {
                    title: '操作',
                    render: (_, row) => <Button size="small" onClick={async () => { setWrongList(await listMyWrongQuestions(row.attemptId)); setWrongOpen(true); }}>错题回顾</Button>,
                  },
                ]}
              />
              <Drawer open={wrongOpen} onClose={() => setWrongOpen(false)} title="错题回顾" width={860}>
                <List
                  dataSource={wrongList}
                  renderItem={(w) => (
                    <List.Item>
                      <Space direction="vertical">
                        <Typography.Text strong>{w.examTitle}</Typography.Text>
                        <div>{w.content}</div>
                        <div>你的答案：{w.myAnswer || '未作答'} / 正确答案：{w.answer}</div>
                      </Space>
                    </List.Item>
                  )}
                />
              </Drawer>
            </Card>
          ),
        },
      ]}
    />
  );
}

export default function App() {
  const auth = useAuth();
  if (!auth.accessToken || !auth.user) {
    return <LoginView onLogin={() => auth.setAuth(getAuthState())} />;
  }
  return (
    <Layout className="min-h-screen">
      <Header className="app-header">
        <Typography.Text className="app-header-title">在线考试平台</Typography.Text>
        <Space>
          <Tag color="blue">{auth.user.role}</Tag>
          <Typography.Text style={{ color: 'white' }}>{auth.user.displayName || auth.user.username}</Typography.Text>
          <Button onClick={async () => { await logout(); auth.clear(); }}>退出登录</Button>
        </Space>
      </Header>
      <Content className="mx-auto w-full max-w-7xl p-4">
        {auth.user.role === 'ADMIN' ? <AdminView /> : <StudentView />}
      </Content>
    </Layout>
  );
}
