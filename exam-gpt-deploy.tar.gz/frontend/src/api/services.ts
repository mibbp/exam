import api from './client';
import type {
  AuthUser,
  Exam,
  ExamScoreboardRow,
  MyExamAvailable,
  MyExamHistory,
  PagedResult,
  Question,
  UserRow,
  WrongQuestion,
} from '../types';

export async function login(username: string, password: string) {
  const { data } = await api.post<{ accessToken: string; user: AuthUser }>(
    '/auth/login',
    { username, password },
  );
  return data;
}

export async function logout() {
  await api.post('/auth/logout');
}

export async function listQuestions(params?: {
  keyword?: string;
  type?: string;
  difficulty?: number;
  page?: number;
  pageSize?: number;
}) {
  const { data } = await api.get<PagedResult<Question>>('/questions', { params });
  return data;
}

export async function createQuestion(payload: Partial<Question>) {
  const { data } = await api.post<Question>('/questions', payload);
  return data;
}

export async function updateQuestion(id: number, payload: Partial<Question>) {
  const { data } = await api.patch<Question>(`/questions/${id}`, payload);
  return data;
}

export async function importQuestions(file: File) {
  const formData = new FormData();
  formData.append('file', file);
  const { data } = await api.post('/questions/import', formData);
  return data as { total: number; successCount: number; errors: Array<{ row: number; reason: string }> };
}

export async function listExams(params?: {
  keyword?: string;
  status?: string;
  page?: number;
  pageSize?: number;
}) {
  const { data } = await api.get<PagedResult<Exam>>('/exams', { params });
  return data;
}

export async function getExam(id: number) {
  const { data } = await api.get<Exam>(`/exams/${id}`);
  return data;
}

export async function createExam(payload: {
  title: string;
  description?: string;
  durationMinutes: number;
  startsAt?: string;
  endsAt?: string;
  questionConfigs: Array<{ questionId: number; score: number }>;
}) {
  const { data } = await api.post<Exam>('/exams', payload);
  return data;
}

export async function updateExam(
  id: number,
  payload: Partial<{
    title: string;
    description?: string;
    durationMinutes: number;
    startsAt?: string;
    endsAt?: string;
    questionConfigs: Array<{ questionId: number; score: number }>;
  }>,
) {
  const { data } = await api.patch<Exam>(`/exams/${id}`, payload);
  return data;
}

export async function publishExam(id: number) {
  await api.post(`/exams/${id}/publish`);
}

export async function unpublishExam(id: number) {
  await api.post(`/exams/${id}/unpublish`);
}

export async function closeExam(id: number) {
  await api.post(`/exams/${id}/close`);
}

export async function deleteExam(id: number) {
  await api.delete(`/exams/${id}`);
}

export async function examAnalytics(examId: number) {
  const { data } = await api.get(`/analytics/exams/${examId}`);
  return data as {
    totalAttempts: number;
    avgScore: number;
    maxScore: number;
    minScore: number;
    submitRate: number;
    antiCheatEvents: number;
  };
}

export async function examScoreboard(examId: number, params?: { page?: number; pageSize?: number; keyword?: string }) {
  const { data } = await api.get<PagedResult<ExamScoreboardRow>>(`/exams/${examId}/scoreboard`, { params });
  return data;
}

export async function startAttempt(examId: number) {
  const { data } = await api.post('/attempts/start', { examId });
  return data as { id: number; examId: number };
}

export async function saveAnswer(attemptId: number, questionId: number, answer: string) {
  await api.patch(`/attempts/${attemptId}/answers/${questionId}`, { answer });
}

export async function submitAttempt(attemptId: number) {
  const { data } = await api.post(`/attempts/${attemptId}/submit`);
  return data;
}

export async function reportAntiCheat(attemptId: number, eventType: string, message?: string) {
  const { data } = await api.post('/anti-cheat/events', { attemptId, eventType, message });
  return data as { forcedSubmit: boolean; antiCheatViolationCount: number };
}

export async function getAttemptResult(attemptId: number) {
  const { data } = await api.get(`/attempts/${attemptId}/result`);
  return data;
}

export async function listMyExams() {
  const { data } = await api.get('/my-exams');
  return data as { available: MyExamAvailable[]; history: MyExamHistory[] };
}

export async function listMyWrongQuestions(attemptId?: number) {
  const { data } = await api.get<WrongQuestion[]>('/my-wrong-questions', {
    params: attemptId ? { attemptId } : undefined,
  });
  return data;
}

export async function listUsers(params?: {
  keyword?: string;
  role?: 'ADMIN' | 'STUDENT';
  status?: 'ACTIVE' | 'DISABLED';
  page?: number;
  pageSize?: number;
}) {
  const { data } = await api.get<PagedResult<UserRow>>('/users', { params });
  return data;
}

export async function createUser(payload: {
  username: string;
  password: string;
  displayName?: string;
  role: 'ADMIN' | 'STUDENT';
  status?: 'ACTIVE' | 'DISABLED';
}) {
  const { data } = await api.post<UserRow>('/users', payload);
  return data;
}

export async function updateUser(
  id: number,
  payload: Partial<{ displayName?: string; role: 'ADMIN' | 'STUDENT'; status: 'ACTIVE' | 'DISABLED' }>,
) {
  const { data } = await api.patch<UserRow>(`/users/${id}`, payload);
  return data;
}

export async function resetUserPassword(id: number, password: string) {
  await api.post(`/users/${id}/reset-password`, { password });
}

