export type UserRole = 'ADMIN' | 'STUDENT';
export type UserStatus = 'ACTIVE' | 'DISABLED';
export type ExamStatus = 'DRAFT' | 'PUBLISHED' | 'CLOSED';

export interface AuthUser {
  id: number;
  username: string;
  displayName?: string;
  role: UserRole;
  status?: UserStatus;
}

export interface Question {
  id: number;
  type: 'SINGLE' | 'MULTIPLE' | 'TRUE_FALSE';
  content: string;
  options: string[];
  answer: string;
  score: number;
  analysis?: string;
  difficulty: number;
  tags?: string[];
}

export interface Exam {
  id: number;
  title: string;
  description?: string;
  durationMinutes: number;
  startsAt?: string;
  endsAt?: string;
  status: ExamStatus;
  isPublished: boolean;
  examQuestions: Array<{ questionId: number; orderNo: number; scoreOverride?: number | null }>;
  _count?: { attempts: number };
}

export interface PagedResult<T> {
  total: number;
  page: number;
  pageSize: number;
  rows: T[];
}

export interface ExamScoreboardRow {
  id: number;
  userId: number;
  username: string;
  displayName?: string;
  status: string;
  score?: number;
  startedAt?: string;
  submittedAt?: string;
  antiCheatViolationCount: number;
}

export interface UserRow {
  id: number;
  username: string;
  displayName?: string;
  role: UserRole;
  status: UserStatus;
  lastLoginAt?: string;
  createdAt?: string;
}

export interface MyExamAvailable {
  examId: number;
  title: string;
  durationMinutes: number;
  startsAt?: string;
  endsAt?: string;
  questionCount: number;
  canStart: boolean;
  status: 'UPCOMING' | 'READY' | 'ONGOING' | 'FINISHED';
  attemptId?: number | null;
  score?: number | null;
}

export interface MyExamHistory {
  attemptId: number;
  examId: number;
  title: string;
  status: string;
  score?: number | null;
  startedAt?: string;
  submittedAt?: string;
  wrongCount: number;
}

export interface WrongQuestion {
  attemptId: number;
  examId: number;
  examTitle: string;
  questionId: number;
  questionType: string;
  content: string;
  options: string[];
  myAnswer?: string;
  answer: string;
  score: number;
  fullScore: number;
}
